import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { GISMap } from './components/Map/GISMap';
import { WorkflowPanel } from './components/Sidebar/WorkflowPanel';
import { VesselRankPanel } from './components/Sidebar/VesselRankPanel';
import { VesselDetailModal } from './components/VesselDetailModal';
import { ReportModal } from './components/ReportModal';

import type { Investigation, CandidateVessel, ScoringWeights } from './types';
import * as api from './services/api';

export const App: React.FC = () => {
  const [investigation, setInvestigation] = useState<Investigation | null>(null);
  const [activeStep, setActiveStep] = useState<number>(2);
  const [selectedVessel, setSelectedVessel] = useState<CandidateVessel | null>(null);
  const [showReportModal, setShowReportModal] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Map layer toggles
  const [layers, setLayers] = useState({
    sarOverlay: true,
    oilSlick: true,
    envVectors: true,
    backwardTrajectories: true,
    originZone: true,
    aisTracks: true,
    aisGaps: true,
    forecastEnvelopes: true
  });

  const handleToggleLayer = (key: string) => {
    setLayers(prev => ({ ...prev, [key as keyof typeof prev]: !prev[key as keyof typeof prev] }));
  };

  // 1. Load Bay of Bengal Cerulean-matched Incident automatically on startup
  useEffect(() => {
    handleLoadDemo('bob');
  }, []);

  const handleLoadDemo = async (incidentKey: string = 'bob') => {
    setLoading(true);
    setErrorMsg(null);
    try {
      const inv = await api.loadDemoIncident(incidentKey);
      setInvestigation(inv);
      setActiveStep(2);
      setSelectedVessel(null);
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to load incident dataset');
    } finally {
      setLoading(false);
    }
  };

  // 2. Run SAR Segmentation Analysis
  const handleRunAnalysis = async () => {
    if (!investigation) return;
    setLoading(true);
    setErrorMsg(null);
    try {
      const updated = await api.runSARAnalysis(investigation.id);
      setInvestigation(updated);
      setActiveStep(2);
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to run SAR analysis');
    } finally {
      setLoading(false);
    }
  };

  // 3. Trace Origin (Physics Hindcast)
  const handleTraceOrigin = async () => {
    if (!investigation) return;
    setLoading(true);
    setErrorMsg(null);
    try {
      const updated = await api.traceOrigin(investigation.id);
      setInvestigation(updated);
      setActiveStep(3);
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to trace spill origin');
    } finally {
      setLoading(false);
    }
  };

  // 4. Correlate AIS Historical Traffic
  const handleCorrelateAIS = async () => {
    if (!investigation) return;
    setLoading(true);
    setErrorMsg(null);
    try {
      const updated = await api.correlateAIS(investigation.id);
      setInvestigation(updated);
      setActiveStep(4);
      if (updated.ais_correlation?.candidates.length) {
        setSelectedVessel(updated.ais_correlation.candidates[0]);
      }
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to correlate AIS data');
    } finally {
      setLoading(false);
    }
  };

  // 5. Update Scoring Weights
  const handleUpdateWeights = async (weights: ScoringWeights) => {
    if (!investigation || !investigation.ais_correlation) return;
    try {
      const updated = await api.updateScoringWeights(investigation.id, weights);
      setInvestigation(updated);
    } catch (err: any) {
      console.error(err);
    }
  };

  // 6. Forecast Spill Movement
  const handleForecast = async () => {
    if (!investigation) return;
    setLoading(true);
    setErrorMsg(null);
    try {
      const updated = await api.forecastSpill(investigation.id);
      setInvestigation(updated);
      setActiveStep(5);
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to forecast spill');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="app-container">
      {/* Header */}
      <Header
        investigation={investigation}
        loading={loading}
        onLoadDemo={handleLoadDemo}
        onOpenUpload={() => handleLoadDemo('bob')}
        onForecast={handleForecast}
        onOpenReport={() => setShowReportModal(true)}
      />

      {/* Main Workspace */}
      <div className="main-workspace">
        {errorMsg && (
          <div style={{ position: 'absolute', top: 16, left: '50%', transform: 'translateX(-50%)', background: '#f43f5e', color: '#fff', padding: '8px 16px', borderRadius: '6px', zIndex: 1100, fontSize: '13px', fontWeight: 600 }}>
            {errorMsg}
          </div>
        )}

        {/* Interactive GIS Map */}
        <GISMap
          investigation={investigation}
          selectedVessel={selectedVessel}
          onSelectVessel={setSelectedVessel}
          layers={layers}
          onToggleLayer={handleToggleLayer}
        />

        {/* Left Panel: Workflow Controls */}
        <WorkflowPanel
          investigation={investigation}
          activeStep={activeStep}
          setActiveStep={setActiveStep}
          loading={loading}
          onRunAnalysis={handleRunAnalysis}
          onTraceOrigin={handleTraceOrigin}
          onCorrelateAIS={handleCorrelateAIS}
          onForecast={handleForecast}
          onOpenReport={() => setShowReportModal(true)}
        />

        {/* Right Panel: Ranked Candidate Vessels */}
        {investigation && investigation.ais_correlation && (
          <VesselRankPanel
            candidates={investigation.ais_correlation.candidates}
            selectedVessel={selectedVessel}
            onSelectVessel={setSelectedVessel}
            scoringWeights={investigation.scoring_weights}
            onUpdateWeights={handleUpdateWeights}
          />
        )}
      </div>

      {/* Detailed Vessel Inspector Modal */}
      {selectedVessel && (
        <VesselDetailModal
          vessel={selectedVessel}
          onClose={() => setSelectedVessel(null)}
        />
      )}

      {/* Official Evidence Report Dossier Modal */}
      {showReportModal && investigation && (
        <ReportModal
          invId={investigation.id}
          onClose={() => setShowReportModal(false)}
        />
      )}
    </div>
  );
};

export default App;
