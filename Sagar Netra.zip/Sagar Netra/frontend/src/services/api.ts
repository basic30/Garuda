import type { Investigation, ScoringWeights } from '../types';

const API_BASE_URL = 'http://localhost:8000/api';

export async function fetchIncidentsList(): Promise<any[]> {
  const response = await fetch(`${API_BASE_URL}/incidents`);
  if (!response.ok) return [];
  return response.json();
}

export async function loadDemoIncident(incidentKey: string = 'bob'): Promise<Investigation> {
  const response = await fetch(`${API_BASE_URL}/investigations/demo?incident_key=${incidentKey}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' }
  });
  if (!response.ok) {
    throw new Error('Failed to load demo incident');
  }
  return response.json();
}

export async function uploadInvestigation(formData: FormData): Promise<Investigation> {
  const response = await fetch(`${API_BASE_URL}/investigations/upload`, {
    method: 'POST',
    body: formData
  });
  if (!response.ok) {
    throw new Error('Failed to upload custom SAR investigation');
  }
  return response.json();
}

export async function runSARAnalysis(invId: string): Promise<Investigation> {
  const response = await fetch(`${API_BASE_URL}/investigations/${invId}/analyze`, {
    method: 'POST'
  });
  if (!response.ok) {
    throw new Error('Failed to execute SAR segmentation analysis');
  }
  return response.json();
}

export async function traceOrigin(invId: string): Promise<Investigation> {
  const response = await fetch(`${API_BASE_URL}/investigations/${invId}/trace-origin`, {
    method: 'POST'
  });
  if (!response.ok) {
    throw new Error('Failed to run origin hindcast simulation');
  }
  return response.json();
}

export async function correlateAIS(invId: string): Promise<Investigation> {
  const response = await fetch(`${API_BASE_URL}/investigations/${invId}/ais`, {
    method: 'POST'
  });
  if (!response.ok) {
    throw new Error('Failed to correlate historical AIS data');
  }
  return response.json();
}

export async function updateScoringWeights(invId: string, weights: ScoringWeights): Promise<Investigation> {
  const response = await fetch(`${API_BASE_URL}/investigations/${invId}/rank-vessels`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(weights)
  });
  if (!response.ok) {
    throw new Error('Failed to update scoring weights');
  }
  return response.json();
}

export async function forecastSpill(invId: string): Promise<Investigation> {
  const response = await fetch(`${API_BASE_URL}/investigations/${invId}/forecast`, {
    method: 'POST'
  });
  if (!response.ok) {
    throw new Error('Failed to compute spill movement forecast');
  }
  return response.json();
}

export function getReportUrl(invId: string): string {
  return `${API_BASE_URL}/investigations/${invId}/report`;
}
