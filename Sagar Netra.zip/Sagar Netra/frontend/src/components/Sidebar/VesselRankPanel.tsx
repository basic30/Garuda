import React, { useState } from 'react';
import { Anchor, Sliders, ChevronDown, ChevronUp, AlertCircle } from 'lucide-react';
import type { CandidateVessel, ScoringWeights } from '../../types';

interface VesselRankPanelProps {
  candidates: CandidateVessel[];
  selectedVessel: CandidateVessel | null;
  onSelectVessel: (vessel: CandidateVessel) => void;
  scoringWeights: ScoringWeights;
  onUpdateWeights: (weights: ScoringWeights) => void;
}

export const VesselRankPanel: React.FC<VesselRankPanelProps> = ({
  candidates,
  selectedVessel,
  onSelectVessel,
  scoringWeights,
  onUpdateWeights
}) => {
  const [showSliders, setShowSliders] = useState(false);
  const [weights, setWeights] = useState<ScoringWeights>(scoringWeights);

  const handleSliderChange = (key: keyof ScoringWeights, val: number) => {
    const updated = { ...weights, [key]: val };
    setWeights(updated);
    onUpdateWeights(updated);
  };

  const getScoreBadgeClass = (score: number) => {
    if (score >= 80) return 'high';
    if (score >= 50) return 'medium';
    return 'low';
  };

  return (
    <div className="right-panel">
      <div className="panel-header">
        <div className="panel-title">
          <Anchor size={16} /> Candidate Vessel Ranking
        </div>
        <button 
          className="btn btn-secondary" 
          style={{ padding: '4px 8px', fontSize: '11px' }}
          onClick={() => setShowSliders(!showSliders)}
        >
          <Sliders size={12} />
          Weights
          {showSliders ? <ChevronUp size={12} /> : <ChevronDown size={12} />}
        </button>
      </div>

      {/* Configurable Weight Tuning Sliders Drawer */}
      {showSliders && (
        <div style={{ background: 'rgba(15, 23, 42, 0.9)', padding: '14px 20px', borderBottom: '1px solid var(--border-color)' }}>
          <div style={{ fontSize: '11px', color: '#94a3b8', marginBottom: '10px', fontWeight: 600 }}>
            Scoring Criteria Weight Allocations
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', fontSize: '11px' }}>
            <div>
              <div style={{ display: 'flex', justifyContent: 'space-between', color: '#cbd5e1' }}>
                <span>Proximity / Distance ({weights.distance_weight} pts)</span>
              </div>
              <input 
                type="range" min="0" max="40" value={weights.distance_weight}
                onChange={e => handleSliderChange('distance_weight', Number(e.target.value))}
                style={{ width: '100%', accentColor: '#38bdf8' }}
              />
            </div>

            <div>
              <div style={{ display: 'flex', justifyContent: 'space-between', color: '#cbd5e1' }}>
                <span>Trajectory Alignment ({weights.trajectory_weight} pts)</span>
              </div>
              <input 
                type="range" min="0" max="40" value={weights.trajectory_weight}
                onChange={e => handleSliderChange('trajectory_weight', Number(e.target.value))}
                style={{ width: '100%', accentColor: '#38bdf8' }}
              />
            </div>

            <div>
              <div style={{ display: 'flex', justifyContent: 'space-between', color: '#cbd5e1' }}>
                <span>Temporal Overlap ({weights.temporal_weight} pts)</span>
              </div>
              <input 
                type="range" min="0" max="40" value={weights.temporal_weight}
                onChange={e => handleSliderChange('temporal_weight', Number(e.target.value))}
                style={{ width: '100%', accentColor: '#38bdf8' }}
              />
            </div>

            <div>
              <div style={{ display: 'flex', justifyContent: 'space-between', color: '#cbd5e1' }}>
                <span>Speed Anomaly ({weights.speed_weight} pts)</span>
              </div>
              <input 
                type="range" min="0" max="40" value={weights.speed_weight}
                onChange={e => handleSliderChange('speed_weight', Number(e.target.value))}
                style={{ width: '100%', accentColor: '#38bdf8' }}
              />
            </div>

            <div>
              <div style={{ display: 'flex', justifyContent: 'space-between', color: '#cbd5e1' }}>
                <span>AIS Transmission Gap ({weights.anomaly_weight} pts)</span>
              </div>
              <input 
                type="range" min="0" max="40" value={weights.anomaly_weight}
                onChange={e => handleSliderChange('anomaly_weight', Number(e.target.value))}
                style={{ width: '100%', accentColor: '#38bdf8' }}
              />
            </div>
          </div>
        </div>
      )}

      {/* Candidate Vessel List */}
      <div className="panel-body">
        {candidates.length === 0 ? (
          <div style={{ textAlign: 'center', color: '#94a3b8', padding: '30px 10px', fontSize: '12px' }}>
            Run AIS correlation to populate candidate vessel rankings.
          </div>
        ) : (
          candidates.map((cand, idx) => (
            <div
              key={cand.mmsi}
              className={`vessel-card ${selectedVessel?.mmsi === cand.mmsi ? 'selected' : ''}`}
              onClick={() => onSelectVessel(cand)}
            >
              <div className="vessel-header">
                <div>
                  <span style={{ fontSize: '11px', color: '#38bdf8', fontWeight: 700, marginRight: '6px' }}>
                    #{idx + 1}
                  </span>
                  <span className="vessel-name">{cand.name}</span>
                </div>
                <div className={`score-badge ${getScoreBadgeClass(cand.attribution_score)}`}>
                  {cand.attribution_score} / 100
                </div>
              </div>

              <div className="vessel-meta">
                <span>MMSI: {cand.mmsi}</span>
                <span>Type: {cand.vessel_type}</span>
                <span>Min Dist: {cand.min_distance_km} km</span>
              </div>

              <ul className="rationale-list">
                {cand.rationale.slice(0, 3).map((r, i) => (
                  <li key={i} className="rationale-item">
                    <span>{r}</span>
                  </li>
                ))}
              </ul>

              {cand.dark_interval?.detected && (
                <div style={{ marginTop: '8px', fontSize: '11px', color: '#f43f5e', fontWeight: 600, display: 'flex', alignItems: 'center', gap: '4px' }}>
                  <AlertCircle size={12} />
                  AIS Dark Interval: {cand.dark_interval.gap_duration_minutes} min gap
                </div>
              )}
            </div>
          ))
        )}
      </div>
    </div>
  );
};
