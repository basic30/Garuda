import React, { useState } from 'react';
import { 
  ShieldAlert, Compass, Wind, Waves, 
  ArrowRight, CheckCircle2, AlertTriangle, Filter
} from 'lucide-react';
import type { Investigation } from '../../types';
import { CeruleanFilterBar } from './CeruleanFilterBar';

interface WorkflowPanelProps {
  investigation: Investigation | null;
  activeStep: number;
  setActiveStep: (step: number) => void;
  loading: boolean;
  onRunAnalysis: () => void;
  onTraceOrigin: () => void;
  onCorrelateAIS: () => void;
  onForecast: () => void;
  onOpenReport: () => void;
}

export const WorkflowPanel: React.FC<WorkflowPanelProps> = ({
  investigation,
  activeStep,
  setActiveStep,
  loading,
  onRunAnalysis,
  onTraceOrigin,
  onCorrelateAIS,
  onForecast,
  onOpenReport
}) => {
  const [showCeruleanFilters, setShowCeruleanFilters] = useState<boolean>(false);
  const [minConfidence, setMinConfidence] = useState<number>(80);
  const [minArea, setMinArea] = useState<number>(5);
  const [selectedClasses, setSelectedClasses] = useState<string[]>(['class2', 'class3']);
  const [dateRange, setDateRange] = useState<string>('2025-08-29_2026-08-29');

  const toggleClass = (cls: string) => {
    if (selectedClasses.includes(cls)) {
      setSelectedClasses(selectedClasses.filter(c => c !== cls));
    } else {
      setSelectedClasses([...selectedClasses, cls]);
    }
  };

  if (!investigation) {
    return (
      <div className="sidebar-panel">
        <div className="panel-header">
          <div className="panel-title">
            <Compass size={16} /> Investigation Workflow
          </div>
        </div>
        <div className="panel-body" style={{ textAlign: 'center', padding: '40px 20px' }}>
          <ShieldAlert size={36} color="#38bdf8" style={{ margin: '0 auto 16px' }} />
          <div style={{ fontSize: '15px', fontWeight: 600, color: '#fff', marginBottom: '8px' }}>
            No Active Incident Loaded
          </div>
          <div style={{ fontSize: '12px', color: '#94a3b8', lineHeight: 1.5 }}>
            Click <strong>"Bay of Bengal Incident"</strong> in the top header bar to initiate an authentic Sentinel-1 SAR investigation workspace.
          </div>
        </div>
      </div>
    );
  }

  const sar = investigation.sar_detection;
  const trace = investigation.origin_trace;
  const ais = investigation.ais_correlation;

  return (
    <div className="sidebar-panel">
      <div className="panel-header">
        <div className="panel-title">
          <Compass size={16} /> Workflow Stage
        </div>
        <button 
          className="btn btn-secondary" 
          style={{ padding: '4px 8px', fontSize: '11px' }}
          onClick={() => setShowCeruleanFilters(!showCeruleanFilters)}
        >
          <Filter size={12} color="#38bdf8" />
          Cerulean Filters
        </button>
      </div>

      {/* Cerulean Interactive Filters */}
      {showCeruleanFilters && (
        <CeruleanFilterBar
          minConfidence={minConfidence}
          setMinConfidence={setMinConfidence}
          minArea={minArea}
          setMinArea={setMinArea}
          selectedClasses={selectedClasses}
          toggleClass={toggleClass}
          dateRange={dateRange}
          setDateRange={setDateRange}
        />
      )}

      {/* Workflow Navigation Tabs */}
      <div className="workflow-nav">
        <div 
          className={`workflow-tab ${activeStep === 1 ? 'active' : ''} ${sar ? 'completed' : ''}`}
          onClick={() => setActiveStep(1)}
        >
          <span>1. Incident</span>
        </div>

        <div 
          className={`workflow-tab ${activeStep === 2 ? 'active' : ''} ${trace ? 'completed' : ''}`}
          onClick={() => setActiveStep(2)}
        >
          <span>2. SAR ML</span>
        </div>

        <div 
          className={`workflow-tab ${activeStep === 3 ? 'active' : ''} ${ais ? 'completed' : ''}`}
          onClick={() => setActiveStep(3)}
        >
          <span>3. Origin</span>
        </div>

        <div 
          className={`workflow-tab ${activeStep === 4 ? 'active' : ''} ${ais ? 'completed' : ''}`}
          onClick={() => setActiveStep(4)}
        >
          <span>4. AIS</span>
        </div>

        <div 
          className={`workflow-tab ${activeStep === 5 ? 'active' : ''} ${investigation.forecast ? 'completed' : ''}`}
          onClick={() => setActiveStep(5)}
        >
          <span>5. Forecast</span>
        </div>
      </div>

      <div className="panel-body">
        {/* STEP 1 — INCIDENT METADATA */}
        {activeStep === 1 && (
          <>
            <div className="metric-card">
              <div className="metric-label">Observation Scene</div>
              <div style={{ fontSize: '14px', fontWeight: 600, color: '#fff' }}>
                {investigation.name}
              </div>
              <div style={{ fontSize: '11px', color: '#38bdf8', marginTop: '4px', fontWeight: 600 }}>
                {investigation.meta?.cerulean_class || "Class 2: Vessel Discharge Slick"}
              </div>
              <div style={{ fontSize: '11px', color: '#94a3b8', marginTop: '2px' }}>
                Sentinel-1 C-SAR Interferometric Wide (IW) Mode, VV Polarization
              </div>
            </div>

            <div className="grid-2">
              <div className="metric-card">
                <div className="metric-label">Observation Time</div>
                <div style={{ fontSize: '12px', fontWeight: 600, color: '#38bdf8' }}>
                  {investigation.meta?.acquisition_time || '2025-11-14 01:30 UTC'}
                </div>
              </div>

              <div className="metric-card">
                <div className="metric-label">Location / Region</div>
                <div style={{ fontSize: '12px', fontWeight: 600, color: '#fff' }}>
                  {investigation.meta?.centroid_geo ? `${investigation.meta.centroid_geo.lat}°N, ${investigation.meta.centroid_geo.lon}°E` : 'Bay of Bengal'}
                </div>
              </div>
            </div>

            <button 
              className="btn btn-primary" 
              style={{ width: '100%', marginTop: '8px' }}
              onClick={onRunAnalysis}
              disabled={loading}
            >
              {loading ? 'Processing ML Pipeline...' : 'START ANALYSIS'}
              <ArrowRight size={15} />
            </button>
          </>
        )}

        {/* STEP 2 — SAR OIL SPILL DETECTION */}
        {activeStep === 2 && sar && sar.geometry && (
          <>
            <div className="metric-card" style={{ borderColor: 'rgba(56, 189, 248, 0.4)' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <div className="metric-label">Detection Status</div>
                <span className="status-pill spill_detected">
                  <CheckCircle2 size={12} /> CONFIRMED
                </span>
              </div>
              <div className="metric-value" style={{ color: '#38bdf8' }}>
                Oil Slick Detected
              </div>
              <div style={{ fontSize: '11px', color: '#94a3b8', marginTop: '2px' }}>
                Cerulean ML Confidence: <strong>{Math.round(sar.confidence * 100)}%</strong>
              </div>
            </div>

            <div className="grid-2">
              <div className="metric-card">
                <div className="metric-label">Estimated Area</div>
                <div className="metric-value">{sar.geometry.area_km2} km²</div>
              </div>

              <div className="metric-card">
                <div className="metric-label">Slick Perimeter</div>
                <div className="metric-value">{sar.geometry.perimeter_km} km</div>
              </div>
            </div>

            <div className="metric-card">
              <div className="metric-label">Slick Centroid Coordinates</div>
              <div className="metric-value" style={{ fontSize: '14px' }}>
                {sar.geometry.centroid.lat}° N, {sar.geometry.centroid.lon}° E
              </div>
            </div>

            <button 
              className="btn btn-primary" 
              style={{ width: '100%', marginTop: '8px' }}
              onClick={onTraceOrigin}
              disabled={loading}
            >
              {loading ? 'Simulating Lagrangian Drift...' : 'TRACE ORIGIN'}
              <ArrowRight size={15} />
            </button>
          </>
        )}

        {/* STEP 3 — ORIGIN TRACE & HINDCAST */}
        {activeStep === 3 && trace && (
          <>
            <div className="metric-card" style={{ borderColor: 'rgba(245, 158, 11, 0.4)' }}>
              <div className="metric-label">Estimated Origin Window</div>
              <div className="metric-value" style={{ fontSize: '13px', color: '#f59e0b' }}>
                {trace.origin_window_start} – {trace.origin_window_end}
              </div>
              <div style={{ fontSize: '11px', color: '#94a3b8', marginTop: '4px' }}>
                Backward Lagrangian Particle Simulation ({trace.particle_count} virtual particles)
              </div>
            </div>

            <div className="grid-2">
              <div className="metric-card">
                <div className="metric-label">Probable Origin Zone</div>
                <div className="metric-value">{trace.origin_area_km2} km²</div>
              </div>

              <div className="metric-card">
                <div className="metric-label">Uncertainty Level</div>
                <div style={{ fontSize: '13px', fontWeight: 600, color: '#10b981', marginTop: '4px' }}>
                  {trace.uncertainty_level}
                </div>
              </div>
            </div>

            <div className="metric-card">
              <div className="metric-label">Environmental Forcing Fields</div>
              <div style={{ fontSize: '12px', color: '#cbd5e1', display: 'flex', flexDirection: 'column', gap: '6px', marginTop: '6px' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                  <Wind size={14} color="#38bdf8" />
                  ERA5 10m Wind: <strong>10.1 knots</strong> (from NW)
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                  <Waves size={14} color="#f59e0b" />
                  CMEMS Current: <strong>0.55 knots</strong> (Northwestward)
                </div>
              </div>
            </div>

            <button 
              className="btn btn-primary" 
              style={{ width: '100%', marginTop: '8px' }}
              onClick={onCorrelateAIS}
              disabled={loading}
            >
              {loading ? 'Filtering AIS Trajectories...' : 'SHOW AIS TRAFFIC'}
              <ArrowRight size={15} />
            </button>
          </>
        )}

        {/* STEP 4 — AIS CORRELATION PIPELINE */}
        {activeStep === 4 && ais && (
          <>
            <div className="metric-card">
              <div className="metric-label">AIS Spatial & Temporal Pipeline</div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', marginTop: '8px' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '12px', color: '#94a3b8' }}>
                  <span>Raw Historical AIS Records:</span>
                  <strong style={{ color: '#fff' }}>{ais.total_records_analyzed}</strong>
                </div>

                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '12px', color: '#94a3b8' }}>
                  <span>Spatial Filter (&lt; 15 km Origin):</span>
                  <strong style={{ color: '#38bdf8' }}>{ais.spatial_filtered_records}</strong>
                </div>

                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '12px', color: '#94a3b8' }}>
                  <span>Temporal Window Filter:</span>
                  <strong style={{ color: '#f59e0b' }}>{ais.temporal_filtered_records}</strong>
                </div>

                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '13px', color: '#fff', fontWeight: 600, borderTop: '1px solid #334155', paddingTop: '6px' }}>
                  <span>Qualified Candidate Vessels:</span>
                  <strong style={{ color: '#f43f5e' }}>{ais.candidate_vessels_count}</strong>
                </div>
              </div>
            </div>

            <div className="metric-card" style={{ backgroundColor: 'rgba(244, 63, 94, 0.1)', borderColor: 'rgba(244, 63, 94, 0.3)' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px', color: '#f43f5e', fontWeight: 600, fontSize: '13px' }}>
                <AlertTriangle size={16} />
                High Priority Candidate Identified
              </div>
              <div style={{ fontSize: '12px', color: '#cbd5e1', marginTop: '4px' }}>
                Top suspect vessel: <strong>{ais.candidates[0]?.name}</strong> (MMSI {ais.candidates[0]?.mmsi}) with Attribution Score <strong>{ais.candidates[0]?.attribution_score}/100</strong>.
              </div>
            </div>

            <button 
              className="btn btn-primary" 
              style={{ width: '100%', marginTop: '8px' }}
              onClick={onForecast}
              disabled={loading}
            >
              {loading ? 'Predicting Future Spread...' : 'FORECAST SPILL'}
              <ArrowRight size={15} />
            </button>
          </>
        )}

        {/* STEP 5 — FORECAST SPILL */}
        {activeStep === 5 && (
          <>
            <div className="metric-card" style={{ borderColor: 'rgba(56, 189, 248, 0.4)' }}>
              <div className="metric-label">Forward Lagrangian Simulation</div>
              <div style={{ fontSize: '14px', fontWeight: 600, color: '#38bdf8' }}>
                Spill Movement Forecast (+48h Horizon)
              </div>
              <div style={{ fontSize: '11px', color: '#94a3b8', marginTop: '4px' }}>
                Predicts future slick movement using real surface wind vectors and CMEMS hydrodynamic current velocities.
              </div>
            </div>

            <div className="metric-card">
              <div className="metric-label">Forecast Probability Steps</div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', marginTop: '6px', fontSize: '12px' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', color: '#38bdf8' }}>
                  <span>+6 Hours:</span>
                  <strong>Spread Radius 1.8 km</strong>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', color: '#0284c7' }}>
                  <span>+12 Hours:</span>
                  <strong>Spread Radius 2.4 km</strong>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', color: '#0369a1' }}>
                  <span>+24 Hours:</span>
                  <strong>Spread Radius 3.2 km</strong>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', color: '#075985' }}>
                  <span>+48 Hours:</span>
                  <strong>Spread Radius 4.5 km</strong>
                </div>
              </div>
            </div>

            <button 
              className="btn btn-primary" 
              style={{ width: '100%', marginTop: '8px' }}
              onClick={onOpenReport}
            >
              GENERATE REPORT DOSSIER
              <ArrowRight size={15} />
            </button>
          </>
        )}
      </div>
    </div>
  );
};
