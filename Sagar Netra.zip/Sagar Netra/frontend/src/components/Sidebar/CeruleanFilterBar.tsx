import React from 'react';
import { Filter, Calendar, ShieldCheck, Sliders, CheckSquare, Square } from 'lucide-react';

interface CeruleanFilterBarProps {
  minConfidence: number;
  setMinConfidence: (val: number) => void;
  minArea: number;
  setMinArea: (val: number) => void;
  selectedClasses: string[];
  toggleClass: (cls: string) => void;
  dateRange: string;
  setDateRange: (range: string) => void;
}

export const CeruleanFilterBar: React.FC<CeruleanFilterBarProps> = ({
  minConfidence,
  setMinConfidence,
  minArea,
  setMinArea,
  selectedClasses,
  toggleClass,
  dateRange,
  setDateRange
}) => {
  const classesList = [
    { id: 'class2', name: 'Class 2: Vessel Discharge' },
    { id: 'class3', name: 'Class 3: Offshore Infrastructure' },
    { id: 'class4', name: 'Class 4: Natural Seep' }
  ];

  return (
    <div style={{ background: 'rgba(15, 23, 42, 0.9)', padding: '14px', borderBottom: '1px solid var(--border-color)', display: 'flex', flexDirection: 'column', gap: '12px' }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', color: '#38bdf8', fontSize: '12px', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.5px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
          <Filter size={14} /> Cerulean Detection Filters
        </div>
        <span style={{ fontSize: '10px', color: '#94a3b8' }}>Live Parameters</span>
      </div>

      {/* Date Range Selector */}
      <div>
        <div style={{ fontSize: '11px', color: '#cbd5e1', marginBottom: '4px', display: 'flex', alignItems: 'center', gap: '4px' }}>
          <Calendar size={12} /> Observation Date Range
        </div>
        <select
          value={dateRange}
          onChange={e => setDateRange(e.target.value)}
          style={{ width: '100%', background: '#1e293b', color: '#fff', border: '1px solid #334155', borderRadius: '4px', padding: '6px 10px', fontSize: '12px', outline: 'none' }}
        >
          <option value="2025-08-29_2026-08-29">2025-08-29 to 2026-08-29 (Last 12 Months)</option>
          <option value="2026-01-01_2026-08-29">2026 Year-To-Date</option>
          <option value="2025-11-01_2025-11-30">November 2025 Incident Window</option>
        </select>
      </div>

      {/* Minimum Confidence Slider */}
      <div>
        <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '11px', color: '#cbd5e1' }}>
          <span style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
            <ShieldCheck size={12} color="#10b981" /> Slick Confidence Threshold
          </span>
          <strong style={{ color: '#38bdf8' }}>{minConfidence}%</strong>
        </div>
        <input
          type="range"
          min="50"
          max="95"
          step="5"
          value={minConfidence}
          onChange={e => setMinConfidence(Number(e.target.value))}
          style={{ width: '100%', accentColor: '#38bdf8', marginTop: '4px' }}
        />
      </div>

      {/* Minimum Slick Area Slider */}
      <div>
        <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '11px', color: '#cbd5e1' }}>
          <span style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
            <Sliders size={12} color="#f59e0b" /> Min Slick Area Filter
          </span>
          <strong style={{ color: '#f59e0b' }}>{minArea} km²</strong>
        </div>
        <input
          type="range"
          min="0"
          max="50"
          step="5"
          value={minArea}
          onChange={e => setMinArea(Number(e.target.value))}
          style={{ width: '100%', accentColor: '#f59e0b', marginTop: '4px' }}
        />
      </div>

      {/* Slick Classification Checkboxes */}
      <div>
        <div style={{ fontSize: '11px', color: '#cbd5e1', marginBottom: '6px' }}>
          Cerulean ML Slick Classes
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
          {classesList.map(cls => {
            const isSelected = selectedClasses.includes(cls.id);
            return (
              <div
                key={cls.id}
                onClick={() => toggleClass(cls.id)}
                style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '11px', color: isSelected ? '#fff' : '#94a3b8', cursor: 'pointer' }}
              >
                {isSelected ? <CheckSquare size={14} color="#38bdf8" /> : <Square size={14} color="#64748b" />}
                <span>{cls.name}</span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
