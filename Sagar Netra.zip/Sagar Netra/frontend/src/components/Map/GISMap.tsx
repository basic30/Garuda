import React, { useEffect, useRef, useState } from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import type { Investigation, CandidateVessel } from '../../types';

const MAPBOX_TOKEN = 'pk.eyJ1Ijoic25haGFzaXNoIiwiYSI6ImNtdGVjajQ0ZTEzdWgyd3F3cjhrcG1xOXEifQ.b--r8RL-Epw4f8zmVCH6tQ';

interface GISMapProps {
  investigation: Investigation | null;
  selectedVessel: CandidateVessel | null;
  onSelectVessel: (vessel: CandidateVessel) => void;
  layers: {
    sarOverlay: boolean;
    oilSlick: boolean;
    envVectors: boolean;
    backwardTrajectories: boolean;
    originZone: boolean;
    aisTracks: boolean;
    aisGaps: boolean;
    forecastEnvelopes: boolean;
  };
  onToggleLayer: (layerKey: string) => void;
}

export const GISMap: React.FC<GISMapProps> = ({
  investigation,
  selectedVessel,
  onSelectVessel,
  layers,
  onToggleLayer
}) => {
  const mapRef = useRef<L.Map | null>(null);
  const tileLayerRef = useRef<L.TileLayer | null>(null);
  const layerGroupsRef = useRef<{ [key: string]: L.LayerGroup }>({});
  const [mapStyle, setMapStyle] = useState<'dark' | 'satellite'>('dark');

  // Initialize Mapbox basemap with user's access token
  useEffect(() => {
    if (!mapRef.current) {
      // Initial center: Bay of Bengal offshore (15.4170° N, 82.6650° E)
      const map = L.map('gis-map-container', {
        center: [15.4170, 82.6650],
        zoom: 11,
        zoomControl: false
      });

      L.control.zoom({ position: 'topright' }).addTo(map);

      // Mapbox Dark Basemap Tile URL
      const darkTileUrl = `https://api.mapbox.com/styles/v1/mapbox/dark-v11/tiles/256/{z}/{x}/{y}@2x?access_token=${MAPBOX_TOKEN}`;
      
      const tileLayer = L.tileLayer(darkTileUrl, {
        attribution: '&copy; Mapbox &copy; OpenStreetMap &copy; SkyTruth Cerulean',
        tileSize: 512,
        zoomOffset: -1,
        maxZoom: 19
      }).addTo(map);

      tileLayerRef.current = tileLayer;
      mapRef.current = map;

      // Initialize layer groups
      layerGroupsRef.current = {
        sarOverlay: L.layerGroup().addTo(map),
        oilSlick: L.layerGroup().addTo(map),
        envVectors: L.layerGroup().addTo(map),
        backwardTrajectories: L.layerGroup().addTo(map),
        originZone: L.layerGroup().addTo(map),
        aisTracks: L.layerGroup().addTo(map),
        aisGaps: L.layerGroup().addTo(map),
        forecastEnvelopes: L.layerGroup().addTo(map)
      };
    }
  }, []);

  // Switch between Mapbox Dark and Mapbox Satellite styles
  const handleStyleSwitch = (style: 'dark' | 'satellite') => {
    setMapStyle(style);
    if (!mapRef.current || !tileLayerRef.current) return;

    mapRef.current.removeLayer(tileLayerRef.current);
    
    const styleId = style === 'dark' ? 'mapbox/dark-v11' : 'mapbox/satellite-streets-v12';
    const tileUrl = `https://api.mapbox.com/styles/v1/${styleId}/tiles/256/{z}/{x}/{y}@2x?access_token=${MAPBOX_TOKEN}`;

    const newTileLayer = L.tileLayer(tileUrl, {
      attribution: '&copy; Mapbox &copy; OpenStreetMap',
      tileSize: 512,
      zoomOffset: -1,
      maxZoom: 19
    }).addTo(mapRef.current);

    tileLayerRef.current = newTileLayer;
  };

  // Render investigation features & auto-fit bounds to oil slick
  useEffect(() => {
    const map = mapRef.current;
    if (!map || !investigation) return;

    // Clear previous layer groups
    Object.values(layerGroupsRef.current).forEach(group => group.clearLayers());

    // 1. Oil Slick Polygon & Cerulean-Style High Visibility Overlay
    if (layers.oilSlick && investigation.sar_detection?.geometry) {
      const slickGroup = layerGroupsRef.current.oilSlick;
      const geom = investigation.sar_detection.geometry;
      const ceruleanClass = investigation.meta?.cerulean_class || "Class 2: Vessel Discharge Oil Slick";

      if (geom.polygon_geojson) {
        // High visibility Cerulean-style double contour styling
        const geoLayer = L.geoJSON(geom.polygon_geojson, {
          style: {
            color: '#ec4899',       // Glowing magenta/rose contour outline
            weight: 3.5,
            fillColor: '#06b6d4',   // Neon cyan fill
            fillOpacity: 0.65,
            dashArray: 'none'
          }
        }).bindPopup(`
          <div style="font-size:12px; font-family: var(--font-sans); color: #f8fafc;">
            <div style="font-size: 11px; font-weight: 700; color: #ec4899; text-transform: uppercase; margin-bottom: 4px;">
              CERULEAN SATELLITE DETECTION
            </div>
            <strong style="font-size: 14px; color:#38bdf8;">${ceruleanClass}</strong><br/>
            <div style="margin-top: 6px; display: flex; flex-direction: column; gap: 2px;">
              <div>Detected Area: <strong>${geom.area_km2} km²</strong></div>
              <div>Perimeter: <strong>${geom.perimeter_km} km</strong></div>
              <div>Length / Width: <strong>${geom.length_km} km / ${geom.width_km} km</strong></div>
              <div>ML Confidence: <strong>${Math.round(investigation.sar_detection.confidence * 100)}%</strong></div>
              <div>Acquisition UTC: <strong>${investigation.sar_detection.observation_time}</strong></div>
              <div>Centroid: <strong>${geom.centroid.lat}° N, ${geom.centroid.lon}° E</strong></div>
            </div>
          </div>
        `).addTo(slickGroup);

        // Auto-center and fit map bounds to oil slick on load!
        try {
          const bounds = geoLayer.getBounds();
          if (bounds.isValid()) {
            map.fitBounds(bounds, { padding: [70, 70], maxZoom: 13, animate: true });
          }
        } catch (e) {
          console.error(e);
        }
      }

      // Centroid Radar Badge
      const c = geom.centroid;
      L.circleMarker([c.lat, c.lon], {
        radius: 8,
        color: '#ffffff',
        weight: 2.5,
        fillColor: '#ec4899',
        fillOpacity: 1
      }).bindTooltip("Oil Slick Centroid", { permanent: false }).addTo(slickGroup);
    }

    // 2. SAR Image Extent Overlay
    if (layers.sarOverlay && investigation.sar_detection) {
      const bbox = investigation.sar_detection.geometry?.bbox || {
        min_lat: 15.300, max_lat: 15.534, min_lon: 82.520, max_lon: 82.810
      };
      const bounds: L.LatLngBoundsExpression = [
        [bbox.min_lat, bbox.min_lon],
        [bbox.max_lat, bbox.max_lon]
      ];
      
      const sarGroup = layerGroupsRef.current.sarOverlay;
      L.rectangle(bounds, {
        color: '#38bdf8',
        weight: 1.5,
        dashArray: '6, 6',
        fillColor: '#0284c7',
        fillOpacity: 0.08
      }).bindTooltip("Sentinel-1 SAR Swath Extent", { permanent: false }).addTo(sarGroup);
    }

    // 3. Environmental Wind & Ocean Current Vectors
    if (layers.envVectors && investigation.sar_detection?.geometry) {
      const envGroup = layerGroupsRef.current.envVectors;
      const c = investigation.sar_detection.geometry.centroid;
      
      // Wind vector (ERA5)
      L.polyline([[c.lat, c.lon], [c.lat + 0.035, c.lon - 0.025]], {
        color: '#38bdf8',
        weight: 3.5,
        dashArray: '6, 4'
      }).bindTooltip("ERA5 10m Wind Vector: 10.1 kts", { permanent: false }).addTo(envGroup);

      // Current vector (CMEMS)
      L.polyline([[c.lat, c.lon], [c.lat - 0.02, c.lon + 0.03]], {
        color: '#f59e0b',
        weight: 3.5
      }).bindTooltip("CMEMS Current Vector: 0.55 kts", { permanent: false }).addTo(envGroup);
    }

    // 4. Backward Particle Trajectories (Hindcast)
    if (layers.backwardTrajectories && investigation.origin_trace?.trajectories_geojson) {
      const trajGroup = layerGroupsRef.current.backwardTrajectories;
      L.geoJSON(investigation.origin_trace.trajectories_geojson, {
        style: {
          color: '#38bdf8',
          weight: 1.5,
          opacity: 0.7,
          dashArray: '4, 4'
        }
      }).addTo(trajGroup);
    }

    // 5. Probable Origin Zone Polygon
    if (layers.originZone && investigation.origin_trace?.probable_origin_zone_geojson) {
      const originGroup = layerGroupsRef.current.originZone;
      const origin = investigation.origin_trace;
      
      L.geoJSON(origin.probable_origin_zone_geojson, {
        style: {
          color: '#f59e0b',
          weight: 3,
          fillColor: '#d97706',
          fillOpacity: 0.4,
          dashArray: '8, 8'
        }
      }).bindPopup(`
        <div style="font-size:12px;">
          <strong style="color:#f59e0b;">PROBABLE ORIGIN ZONE</strong><br/>
          Area: <strong>${origin.origin_area_km2} km²</strong><br/>
          Estimated Window: <strong>${origin.origin_window_start} – ${origin.origin_window_end}</strong><br/>
          Uncertainty: <strong>${origin.uncertainty_level}</strong>
        </div>
      `).addTo(originGroup);
    }

    // 6. AIS Vessel Tracks & Candidate Markers
    if (layers.aisTracks && investigation.ais_correlation?.candidates) {
      const aisGroup = layerGroupsRef.current.aisTracks;
      const candidates = investigation.ais_correlation.candidates;

      candidates.forEach(cand => {
        const isSelected = selectedVessel?.mmsi === cand.mmsi;
        const isTop = cand.attribution_score >= 80;

        let strokeColor = isTop ? '#f43f5e' : (cand.attribution_score >= 50 ? '#f59e0b' : '#38bdf8');
        let strokeWidth = isSelected ? 4.5 : (isTop ? 3.5 : 2);

        // Vessel Polyline Track
        const points: L.LatLngExpression[] = cand.trajectory.map(p => [p.lat, p.lon]);
        L.polyline(points, {
          color: strokeColor,
          weight: strokeWidth,
          opacity: isSelected ? 1 : 0.85
        }).addTo(aisGroup);

        // Current / Last Position Marker
        const lastPos = cand.trajectory[cand.trajectory.length - 1];
        const marker = L.circleMarker([lastPos.lat, lastPos.lon], {
          radius: isTop ? 9 : 6,
          color: '#ffffff',
          weight: isSelected ? 3 : 1.5,
          fillColor: strokeColor,
          fillOpacity: 1
        }).bindPopup(`
          <div style="font-size:12px;">
            <strong style="color:${strokeColor}">${cand.name}</strong> (${cand.vessel_type})<br/>
            MMSI: <strong>${cand.mmsi}</strong><br/>
            Attribution Score: <strong>${cand.attribution_score} / 100</strong><br/>
            Priority: <strong>${cand.priority_level}</strong><br/>
            Min Distance: <strong>${cand.min_distance_km} km</strong>
          </div>
        `).addTo(aisGroup);

        marker.on('click', () => {
          onSelectVessel(cand);
        });
      });
    }

    // 7. AIS Transmission Dark Gap Corridors
    if (layers.aisGaps && investigation.ais_correlation?.candidates) {
      const gapGroup = layerGroupsRef.current.aisGaps;
      investigation.ais_correlation.candidates.forEach(cand => {
        if (cand.dark_interval?.detected && cand.dark_interval.plausible_gap_corridor_geojson) {
          L.geoJSON(cand.dark_interval.plausible_gap_corridor_geojson, {
            style: {
              color: '#f43f5e',
              weight: 2.5,
              fillColor: '#f43f5e',
              fillOpacity: 0.3,
              dashArray: '8, 8'
            }
          }).bindPopup(`
            <div style="font-size:12px; color:#f43f5e;">
              <strong>⚠ AIS DARK TRANSMISSION INTERVAL</strong><br/>
              Vessel: <strong>${cand.name}</strong><br/>
              Gap Duration: <strong>${cand.dark_interval.gap_duration_minutes} minutes</strong><br/>
              Last Contact: <strong>${cand.dark_interval.last_known_time}</strong><br/>
              Contact Recovered: <strong>${cand.dark_interval.first_recovered_time}</strong>
            </div>
          `).addTo(gapGroup);
        }
      });
    }

    // 8. Forecast Probability Envelopes (+6h to +48h)
    if (layers.forecastEnvelopes && investigation.forecast?.forecast_steps) {
      const fcGroup = layerGroupsRef.current.forecastEnvelopes;
      const colors = ['#38bdf8', '#0284c7', '#0369a1', '#075985'];

      investigation.forecast.forecast_steps.forEach((step, idx) => {
        L.geoJSON(step.envelope_geojson, {
          style: {
            color: colors[idx % colors.length],
            weight: 2,
            fillColor: colors[idx % colors.length],
            fillOpacity: 0.18 + (idx * 0.05)
          }
        }).bindPopup(`
          <div style="font-size:12px;">
            <strong style="color:#38bdf8;">SPILL FORECAST +${step.hours} HOURS</strong><br/>
            Target UTC: <strong>${step.time_utc}</strong><br/>
            Predicted Centroid: <strong>${step.centroid.lat}° N, ${step.centroid.lon}° E</strong><br/>
            Spread Radius: <strong>${step.spread_radius_km} km</strong>
          </div>
        `).addTo(fcGroup);
      });
    }

  }, [investigation, selectedVessel, layers]);

  return (
    <div className="map-viewport">
      <div id="gis-map-container" style={{ width: '100%', height: '100%' }} />

      {/* Floating Map Style Switcher & Layer Controls */}
      <div className="map-layer-control">
        <div style={{ display: 'flex', gap: '6px', marginRight: '12px', borderRight: '1px solid #334155', paddingRight: '12px' }}>
          <button
            className={`btn ${mapStyle === 'dark' ? 'btn-primary' : 'btn-secondary'}`}
            style={{ padding: '4px 10px', fontSize: '11px' }}
            onClick={() => handleStyleSwitch('dark')}
          >
            Mapbox Dark
          </button>

          <button
            className={`btn ${mapStyle === 'satellite' ? 'btn-primary' : 'btn-secondary'}`}
            style={{ padding: '4px 10px', fontSize: '11px' }}
            onClick={() => handleStyleSwitch('satellite')}
          >
            Mapbox Satellite
          </button>
        </div>

        <label className="layer-toggle">
          <input
            type="checkbox"
            checked={layers.oilSlick}
            onChange={() => onToggleLayer('oilSlick')}
          />
          Oil Slick
        </label>

        <label className="layer-toggle">
          <input
            type="checkbox"
            checked={layers.originZone}
            onChange={() => onToggleLayer('originZone')}
          />
          Origin Zone
        </label>

        <label className="layer-toggle">
          <input
            type="checkbox"
            checked={layers.aisTracks}
            onChange={() => onToggleLayer('aisTracks')}
          />
          AIS Vessels
        </label>

        <label className="layer-toggle">
          <input
            type="checkbox"
            checked={layers.aisGaps}
            onChange={() => onToggleLayer('aisGaps')}
          />
          AIS Dark Gaps
        </label>

        <label className="layer-toggle">
          <input
            type="checkbox"
            checked={layers.forecastEnvelopes}
            onChange={() => onToggleLayer('forecastEnvelopes')}
          />
          Forecast
        </label>
      </div>
    </div>
  );
};
