import React from 'react';
import { X, ShieldAlert, CheckCircle2 } from 'lucide-react';
import type { CandidateVessel } from '../types';

interface VesselDetailModalProps {
  vessel: CandidateVessel | null;
  onClose: () => void;
}

export const VesselDetailModal: React.FC<VesselDetailModalProps> = ({ vessel, onClose }) => {
  if (!vessel) return null;

  const score = vessel.attribution_score;
  const isHigh = score >= 80;

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal-content" onClick={e => e.stopPropagation()}>
        <div className="modal-header">
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
            <div className={`score-badge ${isHigh ? 'high' : 'medium'}`} style={{ fontSize: '16px', padding: '6px 12px' }}>
              {vessel.attribution_score} / 100
            </div>
            <div>
              <div style={{ fontSize: '18px', fontWeight: 700, color: '#fff' }}>
                {vessel.name}
              </div>
              <div style={{ fontSize: '12px', color: '#94a3b8' }}>
                MMSI: <strong>{vessel.mmsi}</strong> | IMO: <strong>{vessel.imo}</strong> | Flag: <strong>{vessel.flag}</strong> | Type: <strong>{vessel.vessel_type}</strong> | Length: <strong>{vessel.length_m}m</strong>
              </div>
            </div>
          </div>
          <button className="btn btn-secondary" style={{ padding: '6px' }} onClick={onClose}>
            <X size={18} />
          </button>
        </div>

        <div className="modal-body" style={{ padding: '24px', display: 'flex', flexDirection: 'column', gap: '20px' }}>
          
          {/* Priority Headline */}
          <div className="metric-card" style={{ backgroundColor: isHigh ? 'rgba(244, 63, 94, 0.12)' : 'rgba(245, 158, 11, 0.12)', borderColor: isHigh ? 'rgba(244, 63, 94, 0.4)' : 'rgba(245, 158, 11, 0.4)' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '10px', color: isHigh ? '#f43f5e' : '#f59e0b', fontSize: '15px', fontWeight: 700 }}>
              <ShieldAlert size={20} />
              {vessel.priority_level}
            </div>
            <div style={{ fontSize: '12px', color: '#cbd5e1', marginTop: '4px' }}>
              Attribution score calculated from spatial proximity, origin zone trajectory intersection, temporal overlap with spill window, speed drop anomalies, and AIS broadcast continuity.
            </div>
          </div>

          {/* Rationale Checklist: WHY THIS VESSEL IS HIGH PRIORITY */}
          <div>
            <div style={{ fontSize: '13px', fontWeight: 700, color: '#38bdf8', textTransform: 'uppercase', marginBottom: '10px', letterSpacing: '0.5px' }}>
              Investigative Rationale & Evidence Checklist
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
              {vessel.rationale.map((item, idx) => (
                <div key={idx} className="metric-card" style={{ padding: '10px 14px', flexDirection: 'row', alignItems: 'center', gap: '10px' }}>
                  <CheckCircle2 size={16} color={item.includes('⚠') ? '#f43f5e' : '#10b981'} />
                  <span style={{ fontSize: '13px', color: '#f8fafc' }}>{item}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Score Component Breakdown Meters */}
          <div>
            <div style={{ fontSize: '13px', fontWeight: 700, color: '#38bdf8', textTransform: 'uppercase', marginBottom: '10px', letterSpacing: '0.5px' }}>
              Attribution Score Breakdown (100-Point Model)
            </div>
            <div className="grid-2">
              <div className="metric-card">
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '12px', color: '#cbd5e1' }}>
                  <span>Proximity / Distance</span>
                  <strong>{vessel.score_breakdown.distance_score} / 25 pts</strong>
                </div>
                <div style={{ height: '6px', background: '#1e293b', borderRadius: '3px', marginTop: '6px', overflow: 'hidden' }}>
                  <div style={{ width: `${(vessel.score_breakdown.distance_score / 25) * 100}%`, height: '100%', background: '#38bdf8' }} />
                </div>
              </div>

              <div className="metric-card">
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '12px', color: '#cbd5e1' }}>
                  <span>Trajectory Alignment</span>
                  <strong>{vessel.score_breakdown.trajectory_score} / 25 pts</strong>
                </div>
                <div style={{ height: '6px', background: '#1e293b', borderRadius: '3px', marginTop: '6px', overflow: 'hidden' }}>
                  <div style={{ width: `${(vessel.score_breakdown.trajectory_score / 25) * 100}%`, height: '100%', background: '#38bdf8' }} />
                </div>
              </div>

              <div className="metric-card">
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '12px', color: '#cbd5e1' }}>
                  <span>Temporal Overlap</span>
                  <strong>{vessel.score_breakdown.temporal_score} / 20 pts</strong>
                </div>
                <div style={{ height: '6px', background: '#1e293b', borderRadius: '3px', marginTop: '6px', overflow: 'hidden' }}>
                  <div style={{ width: `${(vessel.score_breakdown.temporal_score / 20) * 100}%`, height: '100%', background: '#10b981' }} />
                </div>
              </div>

              <div className="metric-card">
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '12px', color: '#cbd5e1' }}>
                  <span>Speed Anomaly</span>
                  <strong>{vessel.score_breakdown.speed_score} / 15 pts</strong>
                </div>
                <div style={{ height: '6px', background: '#1e293b', borderRadius: '3px', marginTop: '6px', overflow: 'hidden' }}>
                  <div style={{ width: `${(vessel.score_breakdown.speed_score / 15) * 100}%`, height: '100%', background: '#f59e0b' }} />
                </div>
              </div>

              <div className="metric-card" style={{ gridColumn: 'span 2' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '12px', color: '#cbd5e1' }}>
                  <span>AIS Transmission Gap (Dark Interval)</span>
                  <strong>{vessel.score_breakdown.anomaly_score} / 15 pts</strong>
                </div>
                <div style={{ height: '6px', background: '#1e293b', borderRadius: '3px', marginTop: '6px', overflow: 'hidden' }}>
                  <div style={{ width: `${(vessel.score_breakdown.anomaly_score / 15) * 100}%`, height: '100%', background: '#f43f5e' }} />
                </div>
              </div>
            </div>
          </div>

          {/* AIS Dark Interval Details */}
          {vessel.dark_interval?.detected && (
            <div>
              <div style={{ fontSize: '13px', fontWeight: 700, color: '#f43f5e', textTransform: 'uppercase', marginBottom: '10px', letterSpacing: '0.5px' }}>
                AIS Dark Transmission Interval Analysis
              </div>
              <div className="metric-card" style={{ backgroundColor: 'rgba(244, 63, 94, 0.08)', borderColor: 'rgba(244, 63, 94, 0.3)' }}>
                <div className="grid-2">
                  <div>
                    <div className="metric-label">Gap Duration</div>
                    <div style={{ fontSize: '16px', fontWeight: 700, color: '#f43f5e' }}>
                      {vessel.dark_interval.gap_duration_minutes} Minutes
                    </div>
                  </div>
                  <div>
                    <div className="metric-label">Corridor Status</div>
                    <div style={{ fontSize: '13px', fontWeight: 600, color: '#f8fafc', marginTop: '2px' }}>
                      Intersects Origin Zone Corridor
                    </div>
                  </div>
                </div>

                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '12px', color: '#94a3b8', marginTop: '12px', borderTop: '1px solid rgba(244, 63, 94, 0.2)', paddingTop: '8px' }}>
                  <div>Last Contact: <strong>{vessel.dark_interval.last_known_time}</strong> ({vessel.dark_interval.last_known_pos.lat}°N, {vessel.dark_interval.last_known_pos.lon}°E)</div>
                  <div>Recovered: <strong>{vessel.dark_interval.first_recovered_time}</strong> ({vessel.dark_interval.first_recovered_pos.lat}°N, {vessel.dark_interval.first_recovered_pos.lon}°E)</div>
                </div>
              </div>
            </div>
          )}

        </div>
      </div>
    </div>
  );
};
