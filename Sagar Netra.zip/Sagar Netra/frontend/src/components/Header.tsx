import React from 'react';
import { Shield, Play, Upload, FileText, Navigation, RefreshCw, Globe } from 'lucide-react';
import type { Investigation } from '../types';

interface HeaderProps {
  investigation: Investigation | null;
  loading: boolean;
  onLoadDemo: (incidentKey: string) => void;
  onOpenUpload: () => void;
  onForecast: () => void;
  onOpenReport: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  investigation,
  loading,
  onLoadDemo,
  onOpenUpload,
  onForecast,
  onOpenReport
}) => {
  const getStatusLabel = (status?: string) => {
    switch (status) {
      case 'INITIALIZED': return '1. Observation Ready';
      case 'SPILL_DETECTED': return '2. Slick Detected';
      case 'ORIGIN_TRACED': return '3. Origin Traced';
      case 'AIS_CORRELATED': return '4. AIS Correlated';
      case 'FORECAST_READY': return '5. Forecast Complete';
      default: return 'Standby Workspace';
    }
  };

  const getStatusClass = (status?: string) => {
    switch (status) {
      case 'SPILL_DETECTED': return 'spill_detected';
      case 'ORIGIN_TRACED': return 'origin_traced';
      case 'AIS_CORRELATED': return 'ais_correlated';
      default: return 'initialized';
    }
  };

  return (
    <header className="app-header">
      <div className="brand-section">
        <div className="brand-logo">
          <Shield size={20} />
        </div>
        <div>
          <div className="brand-title">
            SAGAR NETRA
            <span style={{ fontSize: '11px', color: '#38bdf8', padding: '2px 6px', background: 'rgba(56, 189, 248, 0.15)', borderRadius: '4px' }}>
              MAPBOX PROD
            </span>
          </div>
          <div className="brand-subtitle">
            Physics-Informed Maritime Oil Spill Investigation Platform
          </div>
        </div>
      </div>

      {investigation && (
        <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
          <div className="brand-subtitle" style={{ color: '#e2e8f0', fontWeight: 600 }}>
            {investigation.name}
          </div>
          <div className={`status-pill ${getStatusClass(investigation.status)}`}>
            <Navigation size={12} />
            {getStatusLabel(investigation.status)}
          </div>
        </div>
      )}

      <div className="header-actions">
        {/* Incident Selector Dropdown */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
          <button 
            className="btn btn-primary"
            onClick={() => onLoadDemo('bob')}
            disabled={loading}
          >
            <Globe size={15} />
            Bay of Bengal Incident
          </button>

          <button 
            className="btn btn-secondary"
            onClick={() => onLoadDemo('sg')}
            disabled={loading}
          >
            <Play size={15} color="#38bdf8" />
            Singapore Incident
          </button>
        </div>

        <button 
          className="btn btn-secondary"
          onClick={onOpenUpload}
          disabled={loading}
        >
          <Upload size={15} />
          Upload SAR Scene
        </button>

        {investigation && investigation.sar_detection && (
          <button 
            className="btn btn-secondary"
            onClick={onForecast}
            disabled={loading}
          >
            <RefreshCw size={15} />
            Forecast
          </button>
        )}

        {investigation && (
          <button 
            className="btn btn-primary"
            onClick={onOpenReport}
          >
            <FileText size={15} />
            Report
          </button>
        )}
      </div>
    </header>
  );
};
