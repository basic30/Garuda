import React from 'react';
import { X, Printer, FileCheck } from 'lucide-react';
import { getReportUrl } from '../services/api';

interface ReportModalProps {
  invId: string;
  onClose: () => void;
}

export const ReportModal: React.FC<ReportModalProps> = ({ invId, onClose }) => {
  const reportUrl = getReportUrl(invId);

  const handlePrint = () => {
    const iframe = document.getElementById('report-iframe') as HTMLIFrameElement;
    if (iframe && iframe.contentWindow) {
      iframe.contentWindow.print();
    }
  };

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal-content" style={{ width: '950px', height: '90vh' }} onClick={e => e.stopPropagation()}>
        <div className="modal-header">
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
            <FileCheck size={20} color="#38bdf8" />
            <div style={{ fontSize: '16px', fontWeight: 700, color: '#fff' }}>
              Official Investigation Support Report — {invId}
            </div>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
            <button className="btn btn-primary" onClick={handlePrint}>
              <Printer size={15} />
              Print / Save PDF
            </button>

            <button className="btn btn-secondary" style={{ padding: '6px' }} onClick={onClose}>
              <X size={18} />
            </button>
          </div>
        </div>

        <div className="modal-body" style={{ height: 'calc(100% - 60px)', background: '#0b0f19' }}>
          <iframe
            id="report-iframe"
            src={reportUrl}
            title="Investigation Report"
            style={{ width: '100%', height: '100%', border: 'none' }}
          />
        </div>
      </div>
    </div>
  );
};
