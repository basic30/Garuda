export interface GeoPoint {
  lat: number;
  lon: number;
}

export interface GeoBBox {
  min_lat: number;
  max_lat: number;
  min_lon: number;
  max_lon: number;
}

export interface SlickGeometry {
  area_km2: number;
  perimeter_km: number;
  centroid: GeoPoint;
  length_km: number;
  width_km: number;
  orientation_deg: number;
  bbox: GeoBBox;
  polygon_geojson: any;
}

export interface SARDetectionResult {
  oil_spill_detected: boolean;
  confidence: number;
  observation_time: string;
  geometry: SlickGeometry | null;
  mask_image_url: string;
  sar_image_url: string;
}

export interface OriginTraceResult {
  origin_window_start: string;
  origin_window_end: string;
  origin_area_km2: number;
  uncertainty_level: string;
  particle_count: number;
  probable_origin_zone_geojson: any;
  trajectories_geojson: any;
}

export interface AISPosition {
  timestamp: string;
  lat: number;
  lon: number;
  sog: number;
  cog: number;
}

export interface AISDarkInterval {
  detected: boolean;
  gap_duration_minutes: number;
  last_known_pos: GeoPoint;
  first_recovered_pos: GeoPoint;
  last_known_time: string;
  first_recovered_time: string;
  plausible_gap_corridor_geojson: any;
}

export interface ScoreBreakdown {
  distance_score: number;
  trajectory_score: number;
  temporal_score: number;
  speed_score: number;
  anomaly_score: number;
}

export interface CandidateVessel {
  mmsi: number;
  name: string;
  vessel_type: string;
  imo: number;
  flag: string;
  length_m: number;
  attribution_score: number;
  priority_level: string;
  min_distance_km: number;
  temporal_overlap: boolean;
  entered_origin_zone: boolean;
  speed_drop_detected: boolean;
  min_sog: number;
  max_sog: number;
  score_breakdown: ScoreBreakdown;
  rationale: string[];
  dark_interval: AISDarkInterval;
  trajectory: AISPosition[];
}

export interface AISCorrelationResult {
  total_records_analyzed: number;
  spatial_filtered_records: number;
  temporal_filtered_records: number;
  candidate_vessels_count: number;
  candidates: CandidateVessel[];
}

export interface ScoringWeights {
  distance_weight: number;
  trajectory_weight: number;
  temporal_weight: number;
  speed_weight: number;
  anomaly_weight: number;
}

export interface ForecastStep {
  hours: number;
  time_utc: string;
  centroid: GeoPoint;
  spread_radius_km: number;
  envelope_geojson: any;
  particles_geojson: any;
}

export interface ForecastResult {
  spill_id: string;
  forecast_steps: ForecastStep[];
}

export interface Investigation {
  id: string;
  name: string;
  description: string;
  status: 'INITIALIZED' | 'SPILL_DETECTED' | 'ORIGIN_TRACED' | 'AIS_CORRELATED' | 'FORECAST_READY';
  created_at: string;
  sar_detection: SARDetectionResult | null;
  origin_trace: OriginTraceResult | null;
  ais_correlation: AISCorrelationResult | null;
  forecast: ForecastResult | null;
  scoring_weights: ScoringWeights;
  meta?: any;
}
