from typing import Dict, Any, List
from backend.app.schemas import ScoringWeights, CandidateVessel, ScoreBreakdown

class VesselScoringEngine:
    def __init__(self):
        pass

    def rank_candidates(
        self,
        raw_candidates: List[Dict[str, Any]],
        weights: ScoringWeights = ScoringWeights()
    ) -> List[Dict[str, Any]]:
        """
        Calculates explainable multi-factor attribution score (0 to 100) for each candidate vessel.
        """
        ranked = []

        for cand in raw_candidates:
            dist_km = cand["min_distance_km"]
            entered_origin = cand["entered_origin_zone"]
            speed_drop = cand["speed_drop_detected"]
            dark = cand["dark_interval"]["detected"]
            v_type = cand["vessel_type"].lower()

            # 1. Proximity Score (Max dist_weight, default 25)
            # Distance <= 0.5km -> 100%, scaling down to 0% at 15km
            if dist_km <= 0.5:
                dist_factor = 1.0
            elif dist_km >= 15.0:
                dist_factor = 0.05
            else:
                dist_factor = max(0.0, 1.0 - (dist_km - 0.5) / 14.5)
            score_dist = round(dist_factor * weights.distance_weight, 1)

            # 2. Trajectory Alignment Score (Max trajectory_weight, default 25)
            if entered_origin:
                traj_factor = 1.0
            elif dist_km < 2.0:
                traj_factor = 0.7
            elif dist_km < 5.0:
                traj_factor = 0.4
            else:
                traj_factor = 0.1
            score_traj = round(traj_factor * weights.trajectory_weight, 1)

            # 3. Temporal Overlap Score (Max temporal_weight, default 20)
            # All filtered candidates have temporal overlap
            temp_factor = 1.0 if cand["temporal_overlap"] else 0.2
            score_temp = round(temp_factor * weights.temporal_weight, 1)

            # 4. Speed Behavior Score (Max speed_weight, default 15)
            if speed_drop and ("tanker" in v_type or "cargo" in v_type):
                speed_factor = 1.0
            elif speed_drop:
                speed_factor = 0.7
            elif cand["min_sog"] < 4.0:
                speed_factor = 0.5
            else:
                speed_factor = 0.1
            score_speed = round(speed_factor * weights.speed_weight, 1)

            # 5. AIS Transmission Gap Anomaly Score (Max anomaly_weight, default 15)
            if dark and cand["dark_interval"]["gap_duration_minutes"] >= 30:
                anomaly_factor = 1.0
            elif dark:
                anomaly_factor = 0.6
            else:
                anomaly_factor = 0.0
            score_anomaly = round(anomaly_factor * weights.anomaly_weight, 1)

            # Total Score (0 - 100)
            total_score = round(score_dist + score_traj + score_temp + score_speed + score_anomaly, 1)
            total_score = min(100.0, max(0.0, total_score))

            # Priority Level
            if total_score >= 80.0:
                priority = "High Priority Candidate"
            elif total_score >= 50.0:
                priority = "Moderate Attribution"
            else:
                priority = "Low Relevance"

            # Rationale checklists
            rationale = []
            if entered_origin:
                rationale.append("✓ Vessel trajectory directly entered probable origin zone")
            else:
                rationale.append(f"✓ Minimum distance to origin zone: {dist_km} km")

            rationale.append("✓ Temporal overlap with estimated spill window (14:30–17:00 UTC)")

            if speed_drop:
                rationale.append(f"✓ Speed reduction anomaly detected (SOG dropped from {cand['max_sog']} to {cand['min_sog']} knots)")

            if dark:
                gap_mins = cand["dark_interval"]["gap_duration_minutes"]
                rationale.append(f"⚠ AIS dark interval detected: {gap_mins} min gap in broadcast position")
            else:
                rationale.append("ℹ Continuous AIS transmission (No broadcast gaps)")

            if "tanker" in v_type:
                rationale.append("ℹ High-capacity liquid cargo / tanker vessel class")

            cand_result = dict(cand)
            cand_result["attribution_score"] = total_score
            cand_result["priority_level"] = priority
            cand_result["score_breakdown"] = {
                "distance_score": score_dist,
                "trajectory_score": score_traj,
                "temporal_score": score_temp,
                "speed_score": score_speed,
                "anomaly_score": score_anomaly
            }
            cand_result["rationale"] = rationale
            ranked.append(cand_result)

        # Sort descending by attribution score
        ranked.sort(key=lambda x: x["attribution_score"], reverse=True)
        return ranked
