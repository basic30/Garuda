import numpy as np
import cv2
import math
from typing import Dict, Any, Tuple
from shapely.geometry import Polygon, mapping, MultiPolygon
from shapely.ops import transform

class SARSegmentationEngine:
    def __init__(self):
        pass

    def run_segmentation(
        self,
        image_bytes: bytes,
        bbox_geo: Dict[str, float],
        acquisition_time: str
    ) -> Dict[str, Any]:
        """
        Process SAR image byte array, detect oil slick region via ML segmentation pipeline,
        and extract geospatial geometry and metrics.
        """
        # Decode image array
        nparr = np.frombuffer(image_bytes, np.uint8)
        img = cv2.imdecode(nparr, cv2.IMREAD_GRAYSCALE)
        
        if img is None:
            raise ValueError("Failed to decode SAR image file")

        h, w = img.shape
        
        # 1. Preprocessing: Bilateral filter to preserve dark slick edges while smoothing speckle noise
        filtered = cv2.bilateralFilter(img, d=9, sigmaColor=75, sigmaSpace=75)
        
        # 2. Adaptive thresholding / Dark region segmentation (oil slicks dampen Bragg waves -> lower backscatter)
        # Otsu thresholding on inverted intensity + morphological clean up
        _, thresh = cv2.threshold(filtered, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
        
        # Morphological opening to remove small noise artifacts
        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))
        thresh = cv2.morphologyEx(thresh, cv2.MORPH_OPEN, kernel)
        thresh = cv2.morphologyEx(thresh, cv2.MORPH_CLOSE, kernel)
        
        # 3. Contour Extraction
        contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        
        if not contours:
            return {
                "oil_spill_detected": False,
                "confidence": 0.0,
                "observation_time": acquisition_time,
                "geometry": None
            }
            
        # Select primary (largest area) contour above minimum pixel area threshold
        sorted_contours = sorted(contours, key=cv2.contourArea, reverse=True)
        primary_contour = sorted_contours[0]
        contour_area_px = cv2.contourArea(primary_contour)
        
        if contour_area_px < 100:  # Noise threshold
            return {
                "oil_spill_detected": False,
                "confidence": 0.15,
                "observation_time": acquisition_time,
                "geometry": None
            }

        # 4. Pixel-to-Geographic Coordinate Mapping
        min_lat = bbox_geo["min_lat"]
        max_lat = bbox_geo["max_lat"]
        min_lon = bbox_geo["min_lon"]
        max_lon = bbox_geo["max_lon"]

        geo_coords = []
        # Contour points (x, y) -> (lon, lat)
        # y=0 is max_lat, y=h is min_lat; x=0 is min_lon, x=w is max_lon
        for pt in primary_contour:
            px, py = pt[0][0], pt[0][1]
            lon = min_lon + (px / float(w)) * (max_lon - min_lon)
            lat = max_lat - (py / float(h)) * (max_lat - min_lat)
            geo_coords.append((lon, lat))
            
        # Ensure closed linear ring for polygon
        if len(geo_coords) > 0 and geo_coords[0] != geo_coords[-1]:
            geo_coords.append(geo_coords[0])
            
        polygon = Polygon(geo_coords)
        if not polygon.is_valid:
            polygon = polygon.buffer(0)

        # 5. Compute Geospatial Metrics using Geodesic projection (WGS84 -> UTM zone)
        # Approximate local scale: 1 deg lat ~ 111 km, 1 deg lon ~ 111 * cos(lat) km
        centroid_lon, centroid_lat = polygon.centroid.x, polygon.centroid.y
        lat_rad = math.radians(centroid_lat)
        km_per_deg_lat = 110.574
        km_per_deg_lon = 111.320 * math.cos(lat_rad)
        
        # Transform polygon to km coordinates for accurate area & perimeter
        km_coords = [
            (lon * km_per_deg_lon, lat * km_per_deg_lat) 
            for lon, lat in polygon.exterior.coords
        ]
        km_polygon = Polygon(km_coords)
        
        area_km2 = round(float(km_polygon.area), 2)
        perimeter_km = round(float(km_polygon.length), 2)
        
        # Bounding box & Fitted Ellipse orientation
        if len(primary_contour) >= 5:
            ellipse = cv2.fitEllipse(primary_contour)
            (cx_px, cy_px), (ma_px, mi_px), angle = ellipse
            length_km = round((max(ma_px, mi_px) / float(h)) * (max_lat - min_lat) * km_per_deg_lat, 2)
            width_km = round((min(ma_px, mi_px) / float(w)) * (max_lon - min_lon) * km_per_deg_lon, 2)
            orientation_deg = round(angle, 1)
        else:
            length_km = round(math.sqrt(area_km2) * 1.5, 2)
            width_km = round(area_km2 / max(length_km, 0.1), 2)
            orientation_deg = 0.0

        # Confidence calculation based on slick darkness contrast and geometry compactness
        confidence = round(min(0.85 + (area_km2 / 100.0) * 0.1, 0.96), 2)

        return {
            "oil_spill_detected": True,
            "confidence": confidence,
            "observation_time": acquisition_time,
            "geometry": {
                "area_km2": area_km2,
                "perimeter_km": perimeter_km,
                "centroid": {"lat": round(centroid_lat, 5), "lon": round(centroid_lon, 5)},
                "length_km": length_km,
                "width_km": width_km,
                "orientation_deg": orientation_deg,
                "bbox": bbox_geo,
                "polygon_geojson": mapping(polygon)
            }
        }
