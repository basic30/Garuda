import hashlib
import json
from datetime import datetime
from typing import Dict, Any
from jinja2 import Template

HTML_REPORT_TEMPLATE = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Sagar Netra — Investigation Report {{ investigation.id }}</title>
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #0b0f19; color: #e2e8f0; margin: 0; padding: 40px; }
        .container { max-width: 900px; margin: 0 auto; background-color: #111827; border: 1px solid #1e293b; border-radius: 8px; padding: 32px; box-shadow: 0 10px 30px rgba(0,0,0,0.5); }
        .header { border-bottom: 2px solid #0284c7; padding-bottom: 20px; margin-bottom: 30px; display: flex; justify-content: space-between; align-items: flex-start; }
        .logo-title { font-size: 24px; font-weight: 700; color: #38bdf8; letter-spacing: 1px; }
        .subtitle { font-size: 14px; color: #94a3b8; margin-top: 4px; }
        .badge { background-color: #0369a1; color: #f0f9ff; padding: 4px 12px; border-radius: 4px; font-size: 12px; font-weight: 600; text-transform: uppercase; }
        .section { margin-bottom: 28px; }
        .section-title { font-size: 16px; font-weight: 700; color: #38bdf8; text-transform: uppercase; letter-spacing: 0.5px; border-bottom: 1px solid #1e293b; padding-bottom: 8px; margin-bottom: 14px; }
        .grid-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
        .grid-3 { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 16px; }
        .card { background-color: #1e293b; padding: 14px; border-radius: 6px; border: 1px solid #334155; }
        .card-label { font-size: 11px; color: #94a3b8; text-transform: uppercase; margin-bottom: 4px; }
        .card-value { font-size: 15px; font-weight: 600; color: #f8fafc; }
        table { width: 100%; border-collapse: collapse; margin-top: 10px; font-size: 13px; }
        th { background-color: #1e293b; color: #94a3b8; font-weight: 600; text-align: left; padding: 10px; border-bottom: 1px solid #334155; }
        td { padding: 10px; border-bottom: 1px solid #1e293b; color: #cbd5e1; }
        .high-score { color: #f43f5e; font-weight: 700; }
        .mod-score { color: #fbbf24; font-weight: 600; }
        .low-score { color: #34d399; }
        .checklist { list-style: none; padding: 0; margin: 6px 0 0 0; }
        .checklist li { font-size: 12px; margin-bottom: 4px; color: #cbd5e1; }
        .audit-footer { border-top: 1px dashed #334155; margin-top: 40px; padding-top: 16px; font-size: 11px; color: #64748b; font-family: monospace; display: flex; justify-content: space-between; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <div>
                <div class="logo-title">SAGAR NETRA</div>
                <div class="subtitle">Physics-Informed Maritime Oil Spill Investigation Dossier</div>
            </div>
            <div>
                <span class="badge">OFFICIAL INVESTIGATION DOSSIER</span>
            </div>
        </div>

        <!-- 1. Incident Summary -->
        <div class="section">
            <div class="section-title">1. Incident Overview</div>
            <div class="grid-3">
                <div class="card">
                    <div class="card-label">Incident ID</div>
                    <div class="card-value">{{ investigation.id }}</div>
                </div>
                <div class="card">
                    <div class="card-label">Investigation Name</div>
                    <div class="card-value">{{ investigation.name }}</div>
                </div>
                <div class="card">
                    <div class="card-label">Report Timestamp</div>
                    <div class="card-value">{{ report_timestamp }}</div>
                </div>
            </div>
        </div>

        <!-- 2. Satellite Detection -->
        {% if investigation.sar_detection %}
        <div class="section">
            <div class="section-title">2. Satellite Observation & SAR Detection</div>
            <div class="grid-3">
                <div class="card">
                    <div class="card-label">Detection Result</div>
                    <div class="card-value" style="color: #38bdf8;">OIL SPILL CONFIRMED</div>
                </div>
                <div class="card">
                    <div class="card-label">ML Confidence Score</div>
                    <div class="card-value">{{ (investigation.sar_detection.confidence * 100)|round }}%</div>
                </div>
                <div class="card">
                    <div class="card-label">Slick Area</div>
                    <div class="card-value">{{ investigation.sar_detection.geometry.area_km2 }} km²</div>
                </div>
            </div>
            <div class="grid-3" style="margin-top: 12px;">
                <div class="card">
                    <div class="card-label">Perimeter</div>
                    <div class="card-value">{{ investigation.sar_detection.geometry.perimeter_km }} km</div>
                </div>
                <div class="card">
                    <div class="card-label">Observation Centroid</div>
                    <div class="card-value">{{ investigation.sar_detection.geometry.centroid.lat }}° N, {{ investigation.sar_detection.geometry.centroid.lon }}° E</div>
                </div>
                <div class="card">
                    <div class="card-label">Observation UTC</div>
                    <div class="card-value">{{ investigation.sar_detection.observation_time }}</div>
                </div>
            </div>
        </div>
        {% endif %}

        <!-- 3. Origin Hindcast -->
        {% if investigation.origin_trace %}
        <div class="section">
            <div class="section-title">3. Physics Drift Origin Hindcast</div>
            <div class="grid-3">
                <div class="card">
                    <div class="card-label">Estimated Origin Window</div>
                    <div class="card-value" style="font-size: 13px;">{{ investigation.origin_trace.origin_window_start }} – {{ investigation.origin_trace.origin_window_end }}</div>
                </div>
                <div class="card">
                    <div class="card-label">Probable Origin Zone Area</div>
                    <div class="card-value">{{ investigation.origin_trace.origin_area_km2 }} km²</div>
                </div>
                <div class="card">
                    <div class="card-label">Uncertainty Level</div>
                    <div class="card-value">{{ investigation.origin_trace.uncertainty_level }}</div>
                </div>
            </div>
        </div>
        {% endif %}

        <!-- 4. Candidate Vessel Ranking -->
        {% if investigation.ais_correlation %}
        <div class="section">
            <div class="section-title">4. AIS Candidate Vessel Attribution Ranking</div>
            <div class="card" style="margin-bottom: 12px; font-size: 12px; color: #94a3b8;">
                AIS Records Analyzed: {{ investigation.ais_correlation.total_records_analyzed }} | Spatial Filter: {{ investigation.ais_correlation.spatial_filtered_records }} | Temporal Filter: {{ investigation.ais_correlation.temporal_filtered_records }} | Qualified Candidates: {{ investigation.ais_correlation.candidate_vessels_count }}
            </div>
            <table>
                <thead>
                    <tr>
                        <th>Rank</th>
                        <th>Vessel Name</th>
                        <th>MMSI</th>
                        <th>Type</th>
                        <th>Min Distance</th>
                        <th>Attribution Score</th>
                        <th>Evidence Highlights</th>
                    </tr>
                </thead>
                <tbody>
                    {% for cand in investigation.ais_correlation.candidates %}
                    <tr>
                        <td><strong>#{{ loop.index }}</strong></td>
                        <td><strong>{{ cand.name }}</strong></td>
                        <td>{{ cand.mmsi }}</td>
                        <td>{{ cand.vessel_type }}</td>
                        <td>{{ cand.min_distance_km }} km</td>
                        <td class="{% if cand.attribution_score >= 80 %}high-score{% elif cand.attribution_score >= 50 %}mod-score{% else %}low-score{% endif %}">
                            {{ cand.attribution_score }} / 100
                        </td>
                        <td>
                            <ul class="checklist">
                                {% for r in cand.rationale %}
                                <li>{{ r }}</li>
                                {% endfor %}
                            </ul>
                        </td>
                    </tr>
                    {% endfor %}
                </tbody>
            </table>
        </div>
        {% endif %}

        <!-- 5. Audit Metadata -->
        <div class="audit-footer">
            <div>AUDIT CHECKSUM (SHA-256): {{ checksum }}</div>
            <div>SAGAR NETRA INVESTIGATION ENGINE V1.0-PROD</div>
        </div>
    </div>
</body>
</html>
"""

class ReportGenerator:
    def __init__(self):
        pass

    def generate_html_report(self, investigation_dict: Dict[str, Any]) -> str:
        report_timestamp = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S UTC")
        
        # Calculate SHA256 audit hash of payload
        payload_str = json.dumps(investigation_dict, sort_keys=True)
        checksum = hashlib.sha256(payload_str.encode("utf-8")).hexdigest()[:32].upper()
        
        template = Template(HTML_REPORT_TEMPLATE)
        html_output = template.render(
            investigation=investigation_dict,
            report_timestamp=report_timestamp,
            checksum=checksum
        )
        return html_output
