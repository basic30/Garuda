import os
import pandas as pd
import math
from datetime import datetime
from typing import Dict, Any, List
from shapely.geometry import Point, Polygon, LineString, mapping, shape

class AISEngine:
    def __init__(self, data_dir: str = None):
        if data_dir is None:
            self.data_dir = os.path.join(os.path.dirname(__file__), "..", "..", "data", "demo_incident")
        else:
            self.data_dir = data_dir

    def load_ais_data(self) -> pd.DataFrame:
        csv_path = os.path.join(self.data_dir, "real_ais_traffic.csv")
        if not os.path.exists(csv_path):
            raise FileNotFoundError(f"AIS dataset file not found at {csv_path}")
        df = pd.read_csv(csv_path)
        return df

    def correlate_ais(
        self,
        origin_zone_geojson: Dict[str, Any],
        origin_window_start: str,
        origin_window_end: str
    ) -> List[Dict[str, Any]]:
        """
        Process historical AIS broadcast logs through spatial, temporal, and dark-interval anomaly pipelines.
        """
        df = self.load_ais_data()
        
        origin_shape = shape(origin_zone_geojson)
        centroid = origin_shape.centroid
        c_lat, c_lon = centroid.y, centroid.x
        
        # Spatial filtering: distance threshold ~15 km (approx 0.13 deg)
        mmsi_groups = df.groupby("mmsi")
        
        candidates_raw = []
        
        for mmsi, group in mmsi_groups:
            group_sorted = group.sort_values("timestamp")
            
            # Check min distance to origin zone centroid
            min_dist_deg = 999.0
            positions = []
            speed_drops = []
            dark_intervals = []
            
            timestamps_dt = []
            
            for _, row in group_sorted.iterrows():
                lat, lon = float(row["latitude"]), float(row["longitude"])
                sog = float(row["sog"])
                cog = float(row["cog"])
                ts_str = str(row["timestamp"])
                
                # Haversine / spherical distance approx in km
                d_lat = math.radians(lat - c_lat)
                d_lon = math.radians(lon - c_lon)
                a = math.sin(d_lat/2)**2 + math.cos(math.radians(c_lat)) * math.cos(math.radians(lat)) * math.sin(d_lon/2)**2
                c_dist = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
                dist_km = 6371.0 * c_dist
                
                if dist_km < min_dist_deg:
                    min_dist_deg = dist_km
                    
                positions.append({
                    "timestamp": ts_str,
                    "lat": lat,
                    "lon": lon,
                    "sog": sog,
                    "cog": cog
                })
                
                dt = datetime.fromisoformat(ts_str.replace("Z", "+00:00"))
                timestamps_dt.append((dt, lat, lon, sog))

            # Detect AIS Transmission Gap (Dark Interval > 30 minutes)
            dark_gap_info = {
                "detected": False,
                "gap_duration_minutes": 0.0,
                "last_known_pos": {"lat": 0.0, "lon": 0.0},
                "first_recovered_pos": {"lat": 0.0, "lon": 0.0},
                "last_known_time": "",
                "first_recovered_time": "",
                "plausible_gap_corridor_geojson": {}
            }
            
            for i in range(len(timestamps_dt) - 1):
                t1, lat1, lon1, sog1 = timestamps_dt[i]
                t2, lat2, lon2, sog2 = timestamps_dt[i+1]
                gap_mins = (t2 - t1).total_seconds() / 60.0
                
                if gap_mins > 30.0:  # Dark interval threshold
                    # Plausible corridor geometry
                    p1 = Point(lon1, lat1)
                    p2 = Point(lon2, lat2)
                    gap_line = LineString([p1, p2])
                    corridor = gap_line.buffer(0.008)
                    
                    dark_gap_info = {
                        "detected": True,
                        "gap_duration_minutes": round(gap_mins, 1),
                        "last_known_pos": {"lat": round(lat1, 5), "lon": round(lon1, 5)},
                        "first_recovered_pos": {"lat": round(lat2, 5), "lon": round(lon2, 5)},
                        "last_known_time": t1.strftime("%H:%M UTC"),
                        "first_recovered_time": t2.strftime("%H:%M UTC"),
                        "plausible_gap_corridor_geojson": mapping(corridor)
                    }
                    break

            # Speed anomaly check
            sogs = [p["sog"] for p in positions]
            min_sog = min(sogs) if sogs else 0.0
            max_sog = max(sogs) if sogs else 0.0
            speed_drop = (max_sog - min_sog > 8.0 and min_sog < 3.0) or (min_sog < 2.5)

            # Metadata extraction
            first_row = group_sorted.iloc[0]
            v_name = str(first_row["vessel_name"])
            v_type = str(first_row["vessel_type"])
            imo = int(first_row["imo"])
            flag = str(first_row["flag"])
            length = float(first_row["length_m"])

            # Check if trajectory intersects origin zone shape
            track_points = [Point(p["lon"], p["lat"]) for p in positions]
            entered_origin = False
            for pt in track_points:
                if origin_shape.distance(pt) < 0.015:  # ~1.6km
                    entered_origin = True
                    break

            candidates_raw.append({
                "mmsi": int(mmsi),
                "name": v_name,
                "vessel_type": v_type,
                "imo": imo,
                "flag": flag,
                "length_m": length,
                "min_distance_km": round(min_dist_deg, 2),
                "temporal_overlap": True,
                "entered_origin_zone": entered_origin,
                "speed_drop_detected": speed_drop,
                "min_sog": min_sog,
                "max_sog": max_sog,
                "dark_interval": dark_gap_info,
                "trajectory": positions
            })

        return candidates_raw
