from pydantic import BaseModel, Field
from typing import List, Dict, Any, Optional

class GeoBBox(BaseModel):
    min_lat: float
    max_lat: float
    min_lon: float
    max_lon: float

class GeoPoint(BaseModel):
    lat: float
    lon: float

class SlickGeometry(BaseModel):
    area_km2: float
    perimeter_km: float
    centroid: GeoPoint
    length_km: float
    width_km: float
    orientation_deg: float
    bbox: GeoBBox
    polygon_geojson: Dict[str, Any]

class SARDetectionResult(BaseModel):
    oil_spill_detected: bool
    confidence: float
    observation_time: str
    geometry: Optional[SlickGeometry] = None
    mask_image_url: str = ""
    sar_image_url: str = ""

class OriginTraceResult(BaseModel):
    origin_window_start: str
    origin_window_end: str
    origin_area_km2: float
    uncertainty_level: str
    particle_count: int
    probable_origin_zone_geojson: Dict[str, Any]
    trajectories_geojson: Dict[str, Any]

class AISPosition(BaseModel):
    timestamp: str
    lat: float
    lon: float
    sog: float
    cog: float

class AISDarkInterval(BaseModel):
    detected: bool
    gap_duration_minutes: float
    last_known_pos: GeoPoint
    first_recovered_pos: GeoPoint
    last_known_time: str
    first_recovered_time: str
    plausible_gap_corridor_geojson: Dict[str, Any]

class ScoreBreakdown(BaseModel):
    distance_score: float = Field(..., description="Max 25 pts")
    trajectory_score: float = Field(..., description="Max 25 pts")
    temporal_score: float = Field(..., description="Max 20 pts")
    speed_score: float = Field(..., description="Max 15 pts")
    anomaly_score: float = Field(..., description="Max 15 pts")

class CandidateVessel(BaseModel):
    mmsi: int
    name: str
    vessel_type: str
    imo: int
    flag: str
    length_m: float
    attribution_score: float
    priority_level: str
    min_distance_km: float
    temporal_overlap: bool
    entered_origin_zone: bool
    speed_drop_detected: bool
    min_sog: float
    max_sog: float
    score_breakdown: ScoreBreakdown
    rationale: List[str]
    dark_interval: AISDarkInterval
    trajectory: List[AISPosition]

class AISCorrelationResult(BaseModel):
    total_records_analyzed: int
    spatial_filtered_records: int
    temporal_filtered_records: int
    candidate_vessels_count: int
    candidates: List[CandidateVessel]

class ScoringWeights(BaseModel):
    distance_weight: float = 25.0
    trajectory_weight: float = 25.0
    temporal_weight: float = 20.0
    speed_weight: float = 15.0
    anomaly_weight: float = 15.0

class ForecastStep(BaseModel):
    hours: int
    time_utc: str
    centroid: GeoPoint
    spread_radius_km: float
    envelope_geojson: Dict[str, Any]
    particles_geojson: Dict[str, Any]

class ForecastResult(BaseModel):
    spill_id: str
    forecast_steps: List[ForecastStep]

class Investigation(BaseModel):
    id: str
    name: str
    description: str
    status: str
    created_at: str
    sar_detection: Optional[SARDetectionResult] = None
    origin_trace: Optional[OriginTraceResult] = None
    ais_correlation: Optional[AISCorrelationResult] = None
    forecast: Optional[ForecastResult] = None
    scoring_weights: ScoringWeights = ScoringWeights()
