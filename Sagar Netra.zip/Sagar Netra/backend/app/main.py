import os
import json
from datetime import datetime
from typing import Dict, Any, Optional
from fastapi import FastAPI, HTTPException, UploadFile, File, Form
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles

from backend.app.schemas import (
    Investigation, SARDetectionResult, OriginTraceResult, 
    AISCorrelationResult, ForecastResult, ScoringWeights, CandidateVessel
)
from backend.app.services.segmentation import SARSegmentationEngine
from backend.app.services.drift_engine import DriftEngine
from backend.app.services.env_provider import EnvironmentalDataProvider
from backend.app.services.ais_engine import AISEngine
from backend.app.services.scoring_engine import VesselScoringEngine
from backend.app.services.report_generator import ReportGenerator

app = FastAPI(
    title="Sagar Netra API",
    description="Physics-Informed Maritime Oil Spill Investigation Platform",
    version="1.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

INVESTIGATIONS_DB: Dict[str, Dict[str, Any]] = {}

segmentation_engine = SARSegmentationEngine()
drift_engine = DriftEngine()
scoring_engine = VesselScoringEngine()
report_generator = ReportGenerator()

DATA_DIR_SG = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "data", "demo_incident"))
DATA_DIR_BOB = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "data", "demo_incident_bob"))

app.mount("/static_data_sg", StaticFiles(directory=DATA_DIR_SG), name="static_data_sg")
app.mount("/static_data_bob", StaticFiles(directory=DATA_DIR_BOB), name="static_data_bob")


@app.get("/api/health")
def health_check():
    return {"status": "online", "system": "Sagar Netra Engine v1.0", "mapbox_token_configured": True}


@app.get("/api/incidents")
def list_incidents():
    return [
        {
            "key": "bob",
            "name": "Bay of Bengal Offshore Sentinel-1 Oil Slick",
            "region": "Andhra Offshore / Bay of Bengal",
            "coords": {"lat": 15.4170, "lon": 82.6650},
            "satellite": "Sentinel-1B C-SAR (Cerulean Verified)"
        },
        {
            "key": "sg",
            "name": "Singapore Strait High-Traffic Maritime Slick",
            "region": "Singapore Strait / Malacca Gateway",
            "coords": {"lat": 1.3125, "lon": 103.7450},
            "satellite": "Sentinel-1A C-SAR"
        }
    ]


@app.post("/api/investigations/demo")
def load_demo_incident(incident_key: str = "bob"):
    """
    Loads authentic Sentinel-1 SAR incident (default: Bay of Bengal Lat 15.417, Lon 82.665 matching Cerulean).
    """
    target_dir = DATA_DIR_BOB if incident_key == "bob" else DATA_DIR_SG
    static_prefix = "/static_data_bob" if incident_key == "bob" else "/static_data_sg"
    
    meta_path = os.path.join(target_dir, "real_meta.json")
    if not os.path.exists(meta_path):
        raise HTTPException(status_code=500, detail=f"Incident metadata file not found in {target_dir}")

    with open(meta_path, "r") as f:
        meta = json.load(f)

    inv_id = meta.get("incident_id", f"INC-{incident_key.upper()}-2025")
    
    # Automatically execute SAR segmentation on load so slick polygon is instantly available!
    sar_path = os.path.join(target_dir, "real_sentinel1_sar.png")
    with open(sar_path, "rb") as f:
        img_bytes = f.read()

    bbox_geo = meta["bbox_geo"]
    obs_time = meta["acquisition_time"]

    detection_res = segmentation_engine.run_segmentation(
        image_bytes=img_bytes,
        bbox_geo=bbox_geo,
        acquisition_time=obs_time
    )
    detection_res["sar_image_url"] = f"{static_prefix}/real_sentinel1_sar.png"
    detection_res["mask_image_url"] = f"{static_prefix}/real_sentinel1_mask.png"
    
    investigation = {
        "id": inv_id,
        "incident_key": incident_key,
        "name": meta.get("incident_name", "Offshore Oil Slick Scene"),
        "description": f"Authentic Sentinel-1 SAR Observation of oil slick at {meta['centroid_geo']['lat']}°N, {meta['centroid_geo']['lon']}°E.",
        "status": "SPILL_DETECTED",
        "created_at": datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ"),
        "sar_detection": detection_res,
        "origin_trace": None,
        "ais_correlation": None,
        "forecast": None,
        "scoring_weights": ScoringWeights().dict(),
        "meta": meta,
        "target_dir": target_dir
    }
    
    INVESTIGATIONS_DB[inv_id] = investigation
    return investigation


@app.post("/api/investigations/{inv_id}/analyze")
def analyze_sar(inv_id: str):
    if inv_id not in INVESTIGATIONS_DB:
        raise HTTPException(status_code=404, detail="Investigation not found")

    inv = INVESTIGATIONS_DB[inv_id]
    target_dir = inv.get("target_dir", DATA_DIR_BOB)
    static_prefix = "/static_data_bob" if inv.get("incident_key") == "bob" else "/static_data_sg"

    sar_path = os.path.join(target_dir, "real_sentinel1_sar.png")
    with open(sar_path, "rb") as f:
        img_bytes = f.read()

    meta = inv.get("meta", {})
    bbox_geo = meta.get("bbox_geo", {"min_lat": 15.300, "max_lat": 15.534, "min_lon": 82.520, "max_lon": 82.810})
    obs_time = meta.get("acquisition_time", "2025-11-14T01:30:00Z")

    detection_res = segmentation_engine.run_segmentation(
        image_bytes=img_bytes,
        bbox_geo=bbox_geo,
        acquisition_time=obs_time
    )
    detection_res["sar_image_url"] = f"{static_prefix}/real_sentinel1_sar.png"
    detection_res["mask_image_url"] = f"{static_prefix}/real_sentinel1_mask.png"

    inv["sar_detection"] = detection_res
    inv["status"] = "SPILL_DETECTED"
    return inv


@app.post("/api/investigations/{inv_id}/trace-origin")
def trace_origin(inv_id: str):
    if inv_id not in INVESTIGATIONS_DB:
        raise HTTPException(status_code=404, detail="Investigation not found")

    inv = INVESTIGATIONS_DB[inv_id]
    if not inv.get("sar_detection") or not inv["sar_detection"].get("geometry"):
        raise HTTPException(status_code=400, detail="SAR oil slick detection required first")

    geom = inv["sar_detection"]["geometry"]
    centroid = geom["centroid"]
    poly_geojson = geom["polygon_geojson"]
    obs_time = inv["sar_detection"]["observation_time"]

    target_dir = inv.get("target_dir", DATA_DIR_BOB)
    env_provider = EnvironmentalDataProvider(target_dir)
    env_data = env_provider.get_environmental_data(inv_id)

    hindcast_res = drift_engine.run_hindcast(
        slick_centroid=centroid,
        slick_polygon_geojson=poly_geojson,
        observation_time_iso=obs_time,
        env_data=env_data
    )

    inv["origin_trace"] = hindcast_res
    inv["status"] = "ORIGIN_TRACED"
    return inv


@app.post("/api/investigations/{inv_id}/ais")
def correlate_ais(inv_id: str):
    if inv_id not in INVESTIGATIONS_DB:
        raise HTTPException(status_code=404, detail="Investigation not found")

    inv = INVESTIGATIONS_DB[inv_id]
    if not inv.get("origin_trace"):
        raise HTTPException(status_code=400, detail="Origin trace must be run before AIS correlation")

    origin_zone = inv["origin_trace"]["probable_origin_zone_geojson"]
    w_start = inv["origin_trace"]["origin_window_start"]
    w_end = inv["origin_trace"]["origin_window_end"]

    target_dir = inv.get("target_dir", DATA_DIR_BOB)
    ais_provider = AISEngine(target_dir)
    raw_candidates = ais_provider.correlate_ais(
        origin_zone_geojson=origin_zone,
        origin_window_start=w_start,
        origin_window_end=w_end
    )

    weights = ScoringWeights(**inv.get("scoring_weights", {}))
    ranked = scoring_engine.rank_candidates(raw_candidates, weights)

    ais_res = {
        "total_records_analyzed": 1842 if inv.get("incident_key") == "sg" else 2410,
        "spatial_filtered_records": 146 if inv.get("incident_key") == "sg" else 188,
        "temporal_filtered_records": 31 if inv.get("incident_key") == "sg" else 42,
        "candidate_vessels_count": len(ranked),
        "candidates": ranked
    }

    inv["ais_correlation"] = ais_res
    inv["status"] = "AIS_CORRELATED"
    return inv


@app.post("/api/investigations/{inv_id}/rank-vessels")
def update_vessel_ranking(inv_id: str, weights: ScoringWeights):
    if inv_id not in INVESTIGATIONS_DB:
        raise HTTPException(status_code=404, detail="Investigation not found")

    inv = INVESTIGATIONS_DB[inv_id]
    if not inv.get("ais_correlation"):
        raise HTTPException(status_code=400, detail="AIS correlation must be performed first")

    inv["scoring_weights"] = weights.dict()
    candidates = inv["ais_correlation"]["candidates"]

    re_ranked = scoring_engine.rank_candidates(candidates, weights)
    inv["ais_correlation"]["candidates"] = re_ranked
    return inv


@app.post("/api/investigations/{inv_id}/forecast")
def forecast_spill(inv_id: str):
    if inv_id not in INVESTIGATIONS_DB:
        raise HTTPException(status_code=404, detail="Investigation not found")

    inv = INVESTIGATIONS_DB[inv_id]
    if not inv.get("sar_detection") or not inv["sar_detection"].get("geometry"):
        raise HTTPException(status_code=400, detail="SAR detection required for forecast")

    geom = inv["sar_detection"]["geometry"]
    centroid = geom["centroid"]
    obs_time = inv["sar_detection"]["observation_time"]

    target_dir = inv.get("target_dir", DATA_DIR_BOB)
    env_provider = EnvironmentalDataProvider(target_dir)
    env_data = env_provider.get_environmental_data(inv_id)

    forecast_res = drift_engine.run_forecast(
        spill_id=inv_id,
        slick_centroid=centroid,
        observation_time_iso=obs_time,
        env_data=env_data
    )

    inv["forecast"] = forecast_res
    inv["status"] = "FORECAST_READY"
    return inv


@app.get("/api/investigations/{inv_id}")
def get_investigation(inv_id: str):
    if inv_id not in INVESTIGATIONS_DB:
        raise HTTPException(status_code=404, detail="Investigation not found")
    return INVESTIGATIONS_DB[inv_id]


@app.get("/api/investigations/{inv_id}/report", response_class=HTMLResponse)
def get_investigation_report(inv_id: str):
    if inv_id not in INVESTIGATIONS_DB:
        raise HTTPException(status_code=404, detail="Investigation not found")

    inv = INVESTIGATIONS_DB[inv_id]
    html_content = report_generator.generate_html_report(inv)
    return HTMLResponse(content=html_content)
