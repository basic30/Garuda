import json
from backend.app.main import (
    load_demo_incident, analyze_sar, trace_origin, correlate_ais, 
    update_vessel_ranking, forecast_spill, get_investigation_report
)
from backend.app.schemas import ScoringWeights

def test_full_investigation_flow():
    print("1. Loading demo incident...")
    inv = load_demo_incident()
    inv_id = inv["id"]
    print(f"Incident loaded: {inv_id} — Status: {inv['status']}")
    
    print("\n2. Running SAR Segmentation analysis...")
    inv_analyzed = analyze_sar(inv_id)
    det = inv_analyzed["sar_detection"]
    print(f"Oil Spill Detected: {det['oil_spill_detected']} | Confidence: {det['confidence']} | Area: {det['geometry']['area_km2']} km²")
    
    print("\n3. Running Physics Origin Tracing (Hindcast)...")
    inv_traced = trace_origin(inv_id)
    trace = inv_traced["origin_trace"]
    print(f"Origin Window: {trace['origin_window_start']} - {trace['origin_window_end']} | Area: {trace['origin_area_km2']} km²")
    
    print("\n4. Correlating Historical AIS Traffic...")
    inv_ais = correlate_ais(inv_id)
    ais_res = inv_ais["ais_correlation"]
    print(f"Records Analyzed: {ais_res['total_records_analyzed']} -> Spatial: {ais_res['spatial_filtered_records']} -> Temporal: {ais_res['temporal_filtered_records']} -> Candidates: {ais_res['candidate_vessels_count']}")
    
    top_cand = ais_res["candidates"][0]
    print(f"Top Candidate: {top_cand['name']} (MMSI: {top_cand['mmsi']}) | Score: {top_cand['attribution_score']}/100 | Priority: {top_cand['priority_level']}")
    for r in top_cand["rationale"]:
        print(f"   {r.encode('ascii', 'replace').decode('ascii')}")
        
    print("\n5. Running Forward Spill Forecast...")
    inv_fc = forecast_spill(inv_id)
    fc = inv_fc["forecast"]
    print(f"Forecast calculated for {len(fc['forecast_steps'])} steps (+6h, +12h, +24h, +48h)")
    
    print("\n6. Generating Evidence Report...")
    report_res = get_investigation_report(inv_id)
    html_content = report_res.body.decode("utf-8")
    print(f"Report rendered! Size: {len(html_content)} bytes")
    
    print("\n[SUCCESS] ALL BACKEND TESTS PASSED SUCCESSFULLY!")

if __name__ == "__main__":
    test_full_investigation_flow()
