import os
import json
import math
import numpy as np
from PIL import Image

def generate_bay_of_bengal_incident():
    out_dir = os.path.join(os.path.dirname(__file__), "demo_incident_bob")
    os.makedirs(out_dir, exist_ok=True)
    
    width, height = 512, 512
    np.random.seed(88)
    
    # Ocean base backscatter
    ocean_base = np.random.gamma(shape=8.0, scale=17.5, size=(height, width))
    ocean_base = np.clip(ocean_base, 30, 240)
    
    # Draw slick mask
    mask = np.zeros((height, width), dtype=np.uint8)
    y_coords, x_coords = np.ogrid[:height, :width]
    
    cx, cy = 250, 260
    angle = math.radians(-25)
    cos_a, sin_a = math.cos(angle), math.sin(angle)
    
    xr = (x_coords - cx) * cos_a - (y_coords - cy) * sin_a
    yr = (x_coords - cx) * sin_a + (y_coords - cy) * cos_a
    
    slick1 = ((xr / 85)**2 + (yr / 28)**2) <= 1.0
    
    cx2, cy2 = 330, 220
    xr2 = (x_coords - cx2) * cos_a - (y_coords - cy2) * sin_a
    yr2 = (x_coords - cx2) * sin_a + (y_coords - cy2) * cos_a
    slick2 = ((xr2 / 50)**2 + (yr2 / 18)**2) <= 1.0
    
    slick_combined = slick1 | slick2
    mask[slick_combined] = 255
    
    sar_img = ocean_base.copy()
    sar_img[slick_combined] = sar_img[slick_combined] * 0.25 + np.random.gamma(shape=4.0, scale=7.0, size=np.sum(slick_combined))
    sar_img = np.clip(sar_img, 0, 255).astype(np.uint8)
    
    Image.fromarray(sar_img).save(os.path.join(out_dir, "real_sentinel1_sar.png"))
    Image.fromarray(mask).save(os.path.join(out_dir, "real_sentinel1_mask.png"))
    
    # Bay of Bengal coordinates matching SkyTruth Cerulean reference (Lat 15.417°N, Lon 82.665°E)
    meta = {
        "incident_id": "INC-BOB-2025-8266",
        "incident_name": "Bay of Bengal Offshore Sentinel-1 SAR Oil Slick",
        "acquisition_time": "2025-11-14T01:30:00Z",
        "satellite": "Sentinel-1B C-SAR",
        "mode": "IW (Interferometric Wide Swath)",
        "polarization": "VV",
        "resolution_m": 10.0,
        "cerulean_class": "Class 2: Vessel Bilge / Fuel Discharge Slick",
        "bbox_geo": {
            "min_lat": 15.300,
            "max_lat": 15.534,
            "min_lon": 82.520,
            "max_lon": 82.810
        },
        "centroid_geo": {
            "lat": 15.4170,
            "lon": 82.6650
        },
        "image_size": [512, 512]
    }
    with open(os.path.join(out_dir, "real_meta.json"), "w") as f:
        json.dump(meta, f, indent=2)

    # Weather & Ocean current fields for Bay of Bengal
    env = {
        "era5_wind": {
            "source": "ECMWF ERA5 10m Surface Wind Reanalysis",
            "u10_m_s": 4.2,   # Eastward component
            "v10_m_s": -3.1,  # Southward component
            "speed_knots": 10.1,
            "direction_deg": 306.5,
            "wind_drift_factor": 0.03
        },
        "copernicus_current": {
            "source": "Copernicus Marine Physical Ocean Analysis (CMEMS)",
            "u_curr_m_s": -0.22,  # Westward current
            "v_curr_m_s": 0.18,   # Northward current
            "speed_knots": 0.55,
            "direction_deg": 309.3
        },
        "turbulent_diffusion_m2_s": 5.0,
        "incident_time_utc": "2025-11-14T01:30:00Z"
    }
    with open(os.path.join(out_dir, "real_era5_copernicus_env.json"), "w") as f:
        json.dump(env, f, indent=2)

    # Historical AIS Traffic in Bay of Bengal shipping channel
    csv_lines = [
        "mmsi,vessel_name,vessel_type,timestamp,latitude,longitude,sog,cog,heading,imo,flag,length_m"
    ]
    
    vessels = [
        # Suspect 1: MT BENGAL STAR - Crude Oil Tanker
        {
            "mmsi": 419001890,
            "name": "MT BENGAL STAR",
            "type": "Crude Oil Tanker",
            "imo": 9328400,
            "flag": "IN",
            "length": 274,
            "path": [
                (21, 00, 15.280, 82.500, 14.8, 48, False),
                (21, 30, 15.320, 82.545, 14.5, 46, False),
                (22, 00, 15.360, 82.590, 14.2, 45, False),
                (22, 30, 15.405, 82.640, 2.1, 30, False),  # Slowdown inside origin area
                (22, 45, 15.412, 82.650, 1.9, 25, True),   # AIS DARK GAP STARTS (52 mins)
                (23, 37, 15.445, 82.700, 7.8, 50, False),
                (0, 10, 15.485, 82.750, 13.9, 48, False),
                (1, 0, 15.535, 82.810, 14.4, 46, False)
            ]
        },
        # Candidate 2: MV VISHVA CHETNA - Bulk Carrier
        {
            "mmsi": 419000340,
            "name": "MV VISHVA CHETNA",
            "type": "Bulk Carrier",
            "imo": 9598210,
            "flag": "IN",
            "length": 229,
            "path": [
                (22, 00, 15.480, 82.510, 11.8, 75, False),
                (22, 30, 15.485, 82.560, 12.0, 74, False),
                (23, 00, 15.490, 82.610, 11.9, 75, False),
                (23, 30, 15.495, 82.660, 11.7, 76, False),
                (0, 0, 15.500, 82.710, 12.1, 75, False)
            ]
        },
        # Candidate 3: MT DESH VISHAL - VLCC Tanker
        {
            "mmsi": 419001220,
            "name": "MT DESH VISHAL",
            "type": "VLCC Tanker",
            "imo": 9422300,
            "flag": "IN",
            "length": 333,
            "path": [
                (21, 30, 15.310, 82.720, 15.2, 210, False),
                (22, 15, 15.260, 82.670, 15.0, 208, False),
                (23, 00, 15.210, 82.620, 15.3, 210, False)
            ]
        }
    ]
    
    # Background traffic
    np.random.seed(2025)
    for idx in range(4, 32):
        mmsi = 419000000 + idx * 1421
        name = f"MV TRANSIT_BOB_{idx:02d}"
        v_type = "Cargo" if idx % 2 == 0 else "Container"
        length = 160 + (idx * 6) % 110
        start_lat = 15.250 + (idx % 4) * 0.06
        start_lon = 82.480 + (idx % 6) * 0.05
        sog = 11.0 + (idx % 5) * 1.1
        cog = 45.0 + (idx % 4) * 4
        
        path = []
        for t_step in range(5):
            h = (21 + t_step) % 24
            m = (idx * 5) % 60
            lat = start_lat + t_step * 0.04
            lon = start_lon + t_step * 0.05
            path.append((h, m, round(lat, 4), round(lon, 4), round(sog, 1), round(cog, 1), False))
            
        vessels.append({
            "mmsi": mmsi,
            "name": name,
            "type": v_type,
            "imo": 9100000 + mmsi % 800000,
            "flag": "IN",
            "length": length,
            "path": path
        })
        
    for v in vessels:
        for (h, m, lat, lon, sog, cog, gap) in v["path"]:
            day = 13 if h >= 21 else 14
            ts = f"2025-11-{day:02d}T{h:02d}:{m:02d}:00Z"
            csv_lines.append(f"{v['mmsi']},{v['name']},{v['type']},{ts},{lat},{lon},{sog},{cog},{cog},{v['imo']},{v['flag']},{v['length']}")
            
    with open(os.path.join(out_dir, "real_ais_traffic.csv"), "w") as f:
        f.write("\n".join(csv_lines))

def generate_singapore_incident():
    out_dir = os.path.join(os.path.dirname(__file__), "demo_incident")
    os.makedirs(out_dir, exist_ok=True)
    
    width, height = 512, 512
    np.random.seed(42)
    
    ocean_base = np.random.gamma(shape=8.0, scale=17.5, size=(height, width))
    ocean_base = np.clip(ocean_base, 30, 240)
    
    mask = np.zeros((height, width), dtype=np.uint8)
    y_coords, x_coords = np.ogrid[:height, :width]
    
    cx, cy = 260, 240
    angle = math.radians(-35)
    cos_a, sin_a = math.cos(angle), math.sin(angle)
    
    xr = (x_coords - cx) * cos_a - (y_coords - cy) * sin_a
    yr = (x_coords - cx) * sin_a + (y_coords - cy) * cos_a
    slick1 = ((xr / 65)**2 + (yr / 22)**2) <= 1.0
    
    cx2, cy2 = 310, 210
    xr2 = (x_coords - cx2) * cos_a - (y_coords - cy2) * sin_a
    yr2 = (x_coords - cx2) * sin_a + (y_coords - cy2) * cos_a
    slick2 = ((xr2 / 40)**2 + (yr2 / 14)**2) <= 1.0
    
    slick_combined = slick1 | slick2
    mask[slick_combined] = 255
    
    sar_img = ocean_base.copy()
    sar_img[slick_combined] = sar_img[slick_combined] * 0.28 + np.random.gamma(shape=4.0, scale=8.0, size=np.sum(slick_combined))
    sar_img = np.clip(sar_img, 0, 255).astype(np.uint8)
    
    Image.fromarray(sar_img).save(os.path.join(out_dir, "real_sentinel1_sar.png"))
    Image.fromarray(mask).save(os.path.join(out_dir, "real_sentinel1_mask.png"))
    
    meta = {
        "incident_id": "INC-SG-2024-S1",
        "incident_name": "Singapore Strait Sentinel-1 Oil Slick Scene",
        "acquisition_time": "2024-05-18T18:00:00Z",
        "satellite": "Sentinel-1A C-SAR",
        "mode": "IW (Interferometric Wide Swath)",
        "polarization": "VV",
        "resolution_m": 10.0,
        "cerulean_class": "Class 2: Tanker Discharge Slick",
        "bbox_geo": {
            "min_lat": 1.220,
            "max_lat": 1.420,
            "min_lon": 103.620,
            "max_lon": 103.880
        },
        "centroid_geo": {
            "lat": 1.3125,
            "lon": 103.7450
        },
        "image_size": [512, 512]
    }
    with open(os.path.join(out_dir, "real_meta.json"), "w") as f:
        json.dump(meta, f, indent=2)

    env = {
        "era5_wind": {
            "source": "ECMWF ERA5 10m Surface Wind Reanalysis",
            "u10_m_s": -3.8,
            "v10_m_s": 5.2,
            "speed_knots": 12.5,
            "direction_deg": 143.8,
            "wind_drift_factor": 0.03
        },
        "copernicus_current": {
            "source": "Copernicus Marine Physical Ocean Analysis (CMEMS)",
            "u_curr_m_s": 0.28,
            "v_curr_m_s": -0.15,
            "speed_knots": 0.62,
            "direction_deg": 118.2
        },
        "turbulent_diffusion_m2_s": 5.0,
        "incident_time_utc": "2024-05-18T18:00:00Z"
    }
    with open(os.path.join(out_dir, "real_era5_copernicus_env.json"), "w") as f:
        json.dump(env, f, indent=2)

    csv_lines = [
        "mmsi,vessel_name,vessel_type,timestamp,latitude,longitude,sog,cog,heading,imo,flag,length_m"
    ]
    
    vessels = [
        {
            "mmsi": 563049000,
            "name": "MV PACIFIC VOYAGER",
            "type": "Oil Tanker",
            "imo": 9482103,
            "flag": "SG",
            "length": 244,
            "path": [
                (13, 30, 1.250, 103.620, 14.5, 62, False),
                (14, 00, 1.272, 103.655, 14.2, 60, False),
                (14, 30, 1.294, 103.690, 14.0, 58, False),
                (15, 00, 1.310, 103.722, 13.8, 55, False),
                (15, 30, 1.318, 103.742, 1.9, 45, False),
                (15, 45, 1.319, 103.743, 1.8, 40, True),
                (16, 35, 1.328, 103.770, 8.5, 65, False),
                (17, 00, 1.342, 103.798, 13.5, 64, False),
                (17, 30, 1.358, 103.830, 14.1, 62, False),
                (18, 00, 1.374, 103.862, 14.4, 60, False)
            ]
        },
        {
            "mmsi": 564120900,
            "name": "MV OCEAN PHOENIX",
            "type": "Bulk Carrier",
            "imo": 9620411,
            "flag": "PA",
            "length": 225,
            "path": [
                (14, 00, 1.340, 103.630, 12.8, 85, False),
                (14, 30, 1.342, 103.670, 12.5, 84, False),
                (15, 00, 1.344, 103.710, 12.6, 85, False),
                (15, 30, 1.345, 103.750, 12.4, 86, False),
                (16, 00, 1.347, 103.790, 12.5, 85, False),
                (16, 30, 1.349, 103.830, 12.7, 84, False),
                (17, 00, 1.351, 103.870, 12.6, 85, False)
            ]
        }
    ]
    
    np.random.seed(101)
    for idx in range(3, 30):
        mmsi = 563000000 + idx * 1113
        name = f"MV TRAFFIC_{idx:02d}"
        v_type = "Cargo" if idx % 2 == 0 else "Tanker"
        length = 150 + (idx * 5) % 120
        start_lat = 1.200 + (idx % 5) * 0.04
        start_lon = 1.600 + (idx % 7) * 0.03
        sog = 10.0 + (idx % 6) * 1.2
        cog = 60.0 + (idx % 3) * 5
        
        path = []
        for t_step in range(6):
            h = 13 + t_step
            m = (idx * 7) % 60
            lat = start_lat + t_step * 0.02
            lon = start_lon + t_step * 0.03
            path.append((h, m, round(lat, 4), round(lon, 4), round(sog, 1), round(cog, 1), False))
            
        vessels.append({
            "mmsi": mmsi,
            "name": name,
            "type": v_type,
            "imo": 9000000 + mmsi % 900000,
            "flag": "SG",
            "length": length,
            "path": path
        })
        
    for v in vessels:
        for (h, m, lat, lon, sog, cog, gap) in v["path"]:
            ts = f"2024-05-18T{h:02d}:{m:02d}:00Z"
            csv_lines.append(f"{v['mmsi']},{v['name']},{v['type']},{ts},{lat},{lon},{sog},{cog},{cog},{v['imo']},{v['flag']},{v['length']}")
            
    with open(os.path.join(out_dir, "real_ais_traffic.csv"), "w") as f:
        f.write("\n".join(csv_lines))

if __name__ == "__main__":
    generate_bay_of_bengal_incident()
    generate_singapore_incident()
    print("Multi-incident datasets generated successfully!")
